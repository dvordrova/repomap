# Repomap semantic-contract research v10

## Question

Should Repomap ask the model to perform ordering, uniqueness checks, ref-kind
checks, coverage arithmetic and other bookkeeping, then discard the whole
response if the model gets one of those mechanics wrong?

## Answer

No.

The strongest reusable pattern across structured-generation systems and the
code-intelligence/review projects examined here is:

```text
deterministic producer narrows the world
→ model makes the semantic choice
→ deterministic backend restores identities and normalizes mechanics
→ validation rejects the smallest unsafe claim
→ product projection groups/collapses without deleting evidence
```

For Repomap this becomes:

> **The model chooses, groups, names and explains.  
> The backend orders, deduplicates, canonicalizes, counts, joins, validates and
> publishes.**

This is not “be permissive”. It is a stricter authority boundary: mechanical
truth belongs to code; semantic judgment belongs to the model.

---

# 1. What established approaches actually solve

## Structured Outputs / constrained decoding

Strict JSON-schema output and constrained decoding are excellent for:

- valid JSON;
- required fields;
- enum values;
- array/object shape;
- eliminating unknown fields.

They do **not** prove that:

- the selected ref is semantically appropriate;
- two components are meaningfully distinct;
- a group is useful to a newcomer;
- a proposed path is connected;
- a label matches the source.

Therefore schema-constrained output should reduce syntax burden, not replace
semantic validation.

### Repomap implication

A strict schema could remove some fragile response-shape errors, but it cannot
solve Telebot/Chatto/Restic broad-unit reuse or Study theme quality. It is a
later transport experiment, not the current P0.

## TypeChat

TypeChat explicitly moves from prompt engineering toward schema engineering:

1. derive a prompt from types;
2. validate the response;
3. if invalid, ask the model to repair;
4. summarize deterministically.

The boundary is useful, but Repomap should not copy the extra repair call by
default. Repomap has opaque local refs, saved-response replay and a strong
requirement against prompt-tuning/retry loops. It can often normalize or
localize the error without another provider call.

### Repomap lesson

- Adopt schema-first response design.
- Keep backend normalization and item-local salvage.
- Do not add a second “please repair your JSON/refs” semantic call unless a
  measured future experiment proves it creates more value than simplifying the
  schema.

## PICARD-style constrained decoding

PICARD constrains token generation so invalid formal-language continuations are
rejected during decoding. This is powerful for grammars such as SQL.

### Repomap lesson

Useful for syntax, not conceptual architecture. A grammar can prevent `p4` in a
`unit_refs` array but cannot tell whether one broad unit represents seven real
components.

## DeepSeek JSON output and strict tool calls

DeepSeek supports JSON-oriented output, and its official API also documents a
strict tool-call path. The current Repomap transport uses JSON-object mode,
which ensures much less than a full strict schema.

### Repomap lesson

Create a small provider-capability experiment only after the semantic contract
is simplified:

- same request;
- strict schema when officially supported;
- byte-identical backend resolution;
- no change to authority or salvage semantics;
- no requirement that the free/OpenRouter route support it.

Do not make this a prerequisite for the next product correction.

---

# 2. What the inspiration projects teach

## Haskell for All: “Browse code by meaning”

The strongest directly reusable idea is **sibling-relative labelling**.

Instead of asking the model to label each cluster independently, provide sibling
clusters together and ask for:

- an overarching theme;
- a label for each sibling;
- a distinguishing feature for each sibling.

The extra “distinguishing feature” is temporary model homework. It can be
discarded after the backend verifies that siblings are not merely different
names for the same broad scope.

### Repomap adoption

Architecture component response should include something like:

```json
{
  "name": "Webhook delivery",
  "responsibility": "Delivers queued webhook events",
  "distinguishing_feature": "Background retry and delivery lifecycle",
  "unit_refs": ["u7"],
  "anchor_refs": ["a14", "a19"]
}
```

`distinguishing_feature` is editorial evidence for distinctness, never local
authority. It helps Flash compare siblings instead of inventing isolated labels.

## Graphify

Graphify separates local deterministic code extraction from inferred graph
meaning and labels edges as extracted versus inferred.

### Repomap adoption

- Preserve a visible distinction between local exact facts and interpreted
  groupings.
- Do not let an attractive graph merge the two authorities.
- Every relation/touchpoint projection should state whether it is exact,
  resolved, observed-in-scope, interpreted or unknown.

Graphify’s broad multi-language/tree-sitter strategy is not the immediate
Repomap priority. The useful lesson is authority labelling, not replacing the
current Go substrate.

## codebase-memory-mcp

This project builds a structural knowledge graph locally and exposes focused
queries to agents. The structural engine and the agent’s explanation are
separate layers.

### Repomap adoption

- Local graph/Atlas owns structural truth.
- Model calls should consume small task-shaped projections.
- UI views are queries/projections over accepted identity, not new canonical
  truth.
- Architecture list, canvas and inspector must use the same accepted IDs and
  counts.

## open·kritt

open·kritt explicitly rejects the one-shot “point a model at the whole repo”
pattern. It breaks research into focused tasks, combines outputs, validates
findings, then deduplicates and ranks them.

### Repomap adoption

- Keep Navigator, Architecture, Scout and Adjudication as focused jobs.
- Give each stage a small typed output.
- Deduplication/ranking belongs after generation.
- Verification and product prioritization are separate from model creativity.

open·kritt does not appear to implement Repomap’s exact item-local salvage over
opaque refs; that remains a useful Repomap differentiator.

## Meat

Meat splits large diffs at deterministic file/hunk boundaries, abridges chunks,
then merges them into one reading diff.

### Repomap adoption

For very large Architecture or Study inputs:

```text
deterministic partition
→ bounded semantic summaries
→ deterministic merge/reconciliation
```

This is preferable to one giant model response, but only when current unit
quality and contracts are fixed. Do not add fan-out yet merely because the
pattern exists.

## LaReview

LaReview groups review work by logical flows and risk instead of asking a human
to read the diff file by file.

### Repomap adoption

- Default Study/Mechanism ordering should be job/flow-first, not package-first.
- Source files are evidence behind a question, not the product’s top-level
  organization.
- Diagrams should answer a specific investigation question.

## Galley

Galley deliberately does not call a model. An external agent supplies a guided
review; Galley validates the structured guide and provides a coherent review
surface. It also collapses skimmed/noise changes while keeping everything one
click away.

### Repomap adoption

- Separate semantic authoring from the review/presentation surface.
- The report UI should validate and render accepted data, not perform hidden
  semantic repair.
- “Collapsed by default” is not information loss when counts and one-click
  access remain.
- A source action should be coherent and stable across every view.

## Saga

Saga turns a large diff into an ordered chapter-by-chapter guided tour, each
chapter containing only the relevant hunks.

### Repomap adoption

- Study themes and mechanism fragments should feel like chapters/lenses.
- A chapter needs a distinct purpose and a bounded source set.
- Ordering is editorial for learning; it must not be confused with runtime
  execution order.

## LaReview, Galley, Saga and Meat are primarily development/review references

They help with how to build and review Repomap and with product presentation
ideas. They are not automatic evidence producers for Repomap.

---

# 3. What current best practice does not solve for Repomap

Most structured-generation stacks use one of:

```text
whole object valid
whole object invalid
repair/retry the whole object
```

Repomap needs a more nuanced contract because its output contains independently
useful siblings bound to exact local facts.

Repomap should keep and strengthen:

- field normalization;
- item-local rejection;
- equivalence-class conflict handling;
- accepted-partial publication;
- local-only fallback when zero semantic items survive;
- complete retention accounting;
- saved-response replay under versioned semantics.

This is stricter and more product-preserving than a generic retry loop.

---

# 4. Recommended division of work

## Model responsibilities

### Architecture

- choose meaningful conceptual areas;
- name subsystem/component responsibilities;
- choose supplied units and optional supporting anchors;
- describe why siblings differ;
- express a preferred display order;
- return fewer groups when evidence is weak;
- mark genuinely shared/cross-cutting participation.

### Navigator

- select one advertised action.

### Theme Scout

- propose distinct developer questions;
- choose supplied evidence anchors;
- request local source expansion;
- explain why the theme matters and what will be learned.

### Theme Adjudication

- judge direct/supporting/weak/irrelevant semantic fit;
- write source-backed observations for accepted readings;
- refine the question;
- choose a useful reading order;
- identify bounded unknowns.

## Backend responsibilities

- JSON shape where the provider supports strict schema;
- subsystem/component nesting and deterministic order;
- response-local IDs;
- ref kind;
- ref existence;
- duplicate removal;
- coverage arithmetic;
- canonical kind restoration;
- action→trail/endpoints/evidence restoration;
- unassessed anchor accounting;
- equivalence classes;
- shared participation;
- local remainder;
- acceptance state;
- version/cache/replay identity;
- list/canvas/inspector consistency.

---

# 5. Proposed Architecture response

Prefer a nested schema so the schema itself expresses containment:

```json
{
  "subsystems": [
    {
      "name": "Authentication and identity",
      "description": "Identity provider and login responsibilities",
      "components": [
        {
          "name": "OAuth providers",
          "responsibility": "Exchanges provider credentials and loads profiles",
          "distinguishing_feature": "Provider-specific token and profile adapters",
          "unit_refs": ["u7"],
          "anchor_refs": ["a4", "a9"],
          "shared": false
        }
      ]
    }
  ]
}
```

Remove from model responsibility:

- `g1`/`g2`;
- `subsystem_ref`;
- tagged `{kind,ref}` pairs when the ref catalog already owns kind;
- “subsystem record immediately followed by components”;
- duplicate checks;
- global distinct-ref arithmetic;
- coverage self-check;
- mandatory one-unit-overall filler.

Prompt core:

```text
Use only supplied unit_refs and anchor_refs.
Partial grouping is valid.
Return only groups that add a useful responsibility.
The same unit may participate in multiple components only when the roles are
genuinely cross-cutting; say how the roles differ.
Do not create a model-authored remainder.
```

The backend then:

```text
parse
→ dedupe refs
→ resolve canonical kind
→ reject only dependent unknown required refs
→ classify shared participation
→ compare resolved member/evidence sets
→ preserve valid siblings
→ build local remainder
```

---

# 6. Validator policy

## Normalize

- exact duplicate refs;
- redundant wrong kind for a known opaque ref;
- repeated reading ref;
- overlong prose;
- omitted optional ordering;
- duplicate Boundary/Resource user projection.

## Reject only the dependent item

- unknown required unit ref;
- ambiguous response-local identity;
- component with no surviving semantic support;
- theme whose accepted readings contain no direct support.

## Keep as conflict/shared

- one broad unit intentionally reused with different exact anchors/roles;
- equivalent member sets with different editorial claims;
- cross-cutting components;
- alternative conceptual groupings.

## Stage-level local-only

Only when zero independently useful semantic items survive.

## Terminal

Only when local authority is unsafe:

- revision drift;
- corrupt canonical artifact;
- unsafe source boundary;
- impossible identity/version mismatch.

---

# 7. Testing doctrine

Every semantic-contract change needs metamorphic tests:

1. permutation invariance;
2. duplicate injection;
3. sibling poisoning;
4. known-ref wrong-kind canonicalization;
5. unknown required ref local rejection;
6. package-unit plus symbol-anchor cross-kind participation;
7. broad shared unit with distinct anchor families;
8. equivalent semantic siblings;
9. zero valid items → local-only;
10. adding evidence cannot erase unrelated output;
11. version/cache/replay identity changes when semantics change.

The product gate is not merely “response accepted”. It is:

```text
Did each visible component/theme add useful information?
Did any mechanical error erase useful siblings?
Did the UI preserve every exact witness?
Did any diagram imply stronger relations than the local facts?
```
