# Repomap main — default prompts and validators audit v10

**Reviewed default online semantic stages on current main:**

1. Navigator
2. Architecture synthesis
3. Theme Scout
4. Theme Adjudication

This excludes historical/experimental prompts that do not participate in the
ordinary Atlas-first run.

---

# 1. Executive scorecard

| Stage | Model should do | Model currently also does | Validator blast radius | Priority |
|---|---|---|---|---|
| Navigator | choose startup action | echo trail/endpoints/evidence/empty arrays | whole response | P1 simplify |
| Architecture | group/name/explain | serialize flat grammar, IDs, kinds, uniqueness, coverage self-check | item-local improved, shared slicing now over-deletes | P0 |
| Theme Scout | propose distinct themes and refs | exact duplicate bookkeeping and target cardinality | item-local | P1 normalize |
| Adjudication | judge evidence and refine themes | assess every anchor, repeat role, exhaustive reading order | item-local | P1 simplify |

---

# 2. Navigator

## Current model contract

The model must:

- choose one `action_ref`;
- cite the matching trail;
- cite both endpoints;
- cite every evidence ref;
- return empty intersection/gap arrays;
- preserve exact catalog identity.

## Current backend contract

The backend already stores each action’s:

- surface;
- application operation;
- relation ID;
- evidence IDs.

After the response it sorts and compares all of the echoed data.

## Review

This is a textbook case of asking the model to repeat backend-owned truth.
There is no semantic value in copying the evidence set after the model has
selected the action.

## Recommended v2

Model output:

```json
{
  "version": 2,
  "catalog_ref": "navigator-v2-...",
  "action_ref": "a1"
}
```

Backend:

```text
resolve action
→ restore trail/endpoints/evidence
→ write full recommendation record
```

### Keep strict

- one action only;
- action exists;
- catalog identity matches;
- action was advertised.

### Remove from model responsibility

- entity refs;
- trail refs;
- evidence refs;
- empty arrays;
- target equality arithmetic.

### Tests

- permutation of catalog does not alter resolved record;
- unknown action fails;
- duplicate/extra fields fail schema;
- selected action restores exact relation/endpoints/evidence;
- no provider call for zero actions;
- old v1 cache/replay misses closed.

---

# 3. Architecture synthesis

## Current strengths

- bounded local unit catalog;
- opaque refs;
- partial grouping allowed;
- model does not create relations;
- backend expands refs;
- D229 item-local salvage;
- exact local remainder;
- provider response accounting;
- prompt/candidate/cache versions.

## Current prompt overload

The model must manage:

- a flat tagged record grammar;
- response-local subsystem refs;
- exact record adjacency;
- exact subsystem_ref copying;
- tagged kind/ref objects;
- no duplicate unit/anchor refs;
- global distinct-ref coverage self-check;
- mandatory at-least-one unit;
- optional cross-cutting reuse;
- conceptual grouping and descriptions;
- display order.

This is too much mechanical work around the real semantic task.

## Contradictory/ambiguous language

The prompt says:

```text
never split one unit across components
```

and also:

```text
a unit may legitimately participate in several components
```

The likely intended distinction is “do not rewrite/split unit identity” versus
“the same unit may participate cross-cutting”, but the model has to infer it.

## Current validator progress

Good:

- duplicate refs can be diagnosed locally;
- unknown anchors can be localized;
- empty salvaged subsystems do not necessarily kill siblings;
- equivalent member sets can be coalesced;
- hypothesis is backend-derived;
- partial output publishes.

Bad:

- repeated-unit safety slicing assumes the unit and anchor member sets can be
  intersected into an owned component;
- package units plus symbol anchors produce empty slices;
- Telebot/Chatto meaningful roles disappear;
- a conceptual/shared role is treated as invalid when it has no exclusive
  member ownership.

## Recommended schema

```json
{
  "subsystems": [
    {
      "name": "...",
      "description": "...",
      "components": [
        {
          "name": "...",
          "responsibility": "...",
          "distinguishing_feature": "...",
          "unit_refs": ["u1"],
          "anchor_refs": ["a2"],
          "participation": "owned|shared|cross_cutting"
        }
      ]
    }
  ]
}
```

Backend owns:

- nesting IDs;
- canonical ref kind;
- dedupe;
- order stabilization;
- coverage;
- owned/shared/unclassified classification;
- acceptance state.

## Shared participation model

A visible component can be useful when it has:

```text
shared unit + distinct anchor family + distinct responsibility
```

without claiming an exclusive member slice.

Store independently:

- editorial component identity;
- participating unit refs;
- exact supporting anchor refs;
- exclusive owned member IDs, possibly empty;
- shared member IDs;
- coverage;
- limitations.

The product card should say:

```text
Shared package scope
Distinct exact configuration anchors
No exclusive package ownership inferred
```

## Adaptive units

Before asking the model, split broad units when bounded:

- stable child path;
- package;
- anchor family;
- module/app boundary;
- measured size/heterogeneity.

Never restore raw-member enumeration.

## Prompt core after simplification

```text
Create a useful conceptual grouping from supplied units.
Use only supplied refs.
Partial grouping is valid.
Return fewer groups rather than filler.
A unit may participate in several components only when their responsibilities
are genuinely distinct; explain the distinguishing feature.
Do not create a remainder.
```

## Architecture validator classification

### Normalize

- duplicate refs in one item;
- known ref with redundant wrong kind;
- absent optional hypothesis/order;
- empty subsystem after child salvage.

### Reject item

- unknown required unit;
- component with no surviving unit/anchor/shared-role support;
- invalid prose/schema after local normalization.

### Shared/conflicted

- repeated broad unit with distinct anchor families;
- equivalent owned member sets with distinct semantic responsibilities;
- cross-cutting participation.

### Local-only

Zero useful semantic components.

### Terminal

Only corrupt/stale/unsafe local authority.

---

# 4. Theme Scout

## Current strengths

- a* evidence versus f* retrieval leads;
- editorial-only relation authority;
- item-local response validation;
- prose normalization;
- exact catalog digest;
- source expansion separated locally.

## Mechanical hard failures to relax

### Duplicate anchor in one candidate

Current outcome: reject candidate.

Recommended:

```text
dedupe exact ref
record normalized.anchor_ref++
keep candidate
```

### Duplicate expansion file ref

Normalize and count.

### Target cardinality wording

Current prompt:

```text
Propose 8–12 themes (valid 1–12)
```

Recommended:

```text
Aim for 8–12 when distinct evidence supports them.
Return 1–12; fewer is better than overlap or filler.
```

### Duplicate candidates

Do not necessarily discard information at Scout. Retain candidate equivalence
for Adjudication/reducer, then co-project the final shelf while preserving all
readings.

### Zero valid candidates

Persist semantic-empty status and keep the complete local question/frontier
browse. Do not fabricate themes, but do not make the product appear to have no
information.

---

# 5. Theme Adjudication

## Current strengths

- item-local;
- direct/supporting/weak/irrelevant;
- exact candidate-bound anchor set;
- source-backed observation;
- bounded unknowns;
- overlong prose normalization.

## Current unnecessary burdens

### Every anchor must receive an assessment

Missing assessments can be treated as:

```text
unreviewed
not published
counted in coverage
```

The model should focus on useful evidence, not exhaustive bookkeeping.

### Role repeated by model

Anchor role is backend-owned. Restore it from the catalog.

### Weak/irrelevant observation

A “supported observation” should be required only for direct/supporting.
Weak/irrelevant can carry an optional short rejection reason.

### Duplicate assessment

Deduplicate exact repeats and count normalization.

### Reading order

- remove unknown/duplicate refs locally;
- retain accepted direct/supporting anchors;
- if no order remains, use deterministic accepted-anchor order and mark it as
  backend default;
- model order remains editorial, never runtime order.

### No direct reading

Reject the theme from publication, but retain a diagnostic record. Do not poison
siblings.

### Zero accepted themes

Publish semantic-empty/local browse rather than erasing all available local
questions.

---

# 6. Validation policy across all stages

## Model error should not become product data loss

For each response field classify it as:

| Class | Example | Action |
|---|---|---|
| backend-owned repeat | ref kind, evidence list, role | remove from schema or canonicalize |
| mechanical set issue | exact duplicate | normalize |
| optional editorial | order, hypothesis | default/omit |
| semantic item error | unknown required unit | reject item |
| semantic conflict | shared broad unit, equivalent groups | publish shared/conflicted |
| authority failure | stale/corrupt catalog | terminal |

## Versioning

Any change in:

- response shape;
- normalization;
- salvage;
- acceptance state;
- canonical resolution;

must advance every relevant:

- prompt/request identity;
- result/status version;
- accepted cache contract;
- replay identity;
- report projection/manifest binding.

A saved response may not change from rejected to accepted under an unchanged
semantic identity.

---

# 7. Prompt-quality checks

For every prompt Hermes should produce a table:

```text
sentence
why the model needs it
can backend do it exactly?
failure blast radius
keep / soften / remove
```

Reject prompt instructions that merely tell the model to simulate deterministic
code.

Keep prompt instructions that require semantic judgment:

- usefulness;
- responsibility;
- distinctness;
- evidence fit;
- learning value;
- source-backed explanation.

---

# 8. Required provider-free replay matrix

Use the exact Archive 9 responses.

## Architecture

- Casdoor partial groups survive; shared units explicit.
- etcd remains partial accepted.
- Telebot model roles survive as shared/cross-cutting or bounded conflicts,
  rather than complete local fallback.
- Chatto admin/config/security/lifecycle roles survive without cloned exclusive
  ownership.
- Restic dispatcher/helpers distinction survives honestly.
- no unrelated valid sibling disappears.

## Study

- exact duplicate injection changes only normalization counts;
- missing assessment changes only local coverage;
- semantic duplicates co-project without losing readings;
- core-first ordering does not hide peripheral themes;
- zero semantic output retains local browse.

## Navigator

- model selects action only;
- backend restores exact full record.

---

# 9. Product gate

A green validator is insufficient.

For each accepted report verify:

- every component teaches a distinct responsibility or explicit shared role;
- every theme teaches a distinct question;
- every exact witness remains reachable;
- every diagram line has correct authority;
- lists, canvas and inspector agree;
- no mechanical model mistake deletes unrelated product value.
