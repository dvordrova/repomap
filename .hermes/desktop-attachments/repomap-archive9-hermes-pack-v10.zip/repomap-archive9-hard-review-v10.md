# Repomap Archive 9 — hard review v10

## Scope

Five fresh live runs:

- Casdoor `20260806-163314-casdoor-f1e101f458c5`
- etcd `20260806-163316-etcd-5e46d6a45682`
- Telebot `20260806-163318-telebot-265c26ae8755`
- Chatto `20260806-163320-chatto-0f4e9ee7d764`
- Restic `20260806-163323-restic-accaa84c6dd7`

Every run includes the report, Architecture status, semantic exchanges, Theme
Scout/Adjudication artifacts and manifest.

## Verdict

Archive 9 proves two things simultaneously:

1. D229’s item-local salvage is correct and materially improved etcd.
2. D230’s shared-unit safety net now deletes useful semantic distinctions on
   Telebot and Chatto and weakens Restic.

So the current architecture is no longer “too strict about duplicates” in the
old way. The new problem is subtler:

> The backend avoids duplicate ownership by intersecting a repeated unit with
> anchor-owned members, but this is type-blind. Package units intersected with
> symbol anchors become empty, so useful model-authored responsibilities
> disappear.

This violates the owner objective:

```text
collect as much useful information as possible
+ display it with honest authority
```

---

# 1. Matrix

| Repo | Architecture outcome | Units | Covered | Uncovered | Final components | Study | Associations | Mechanism |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| Casdoor | partial model | 2 | 41 | 15 | 5 | 11 | 218 | 3 transitions |
| etcd | partial model | 21 | 129 | 122 | 8 | 12 | 164 | 51 transitions |
| Telebot | model rejected → local packages | 2 | — | — | 5 local | 9 | 8 | none |
| Chatto | model rejected → local anchors | 4 | — | — | 5 local | 11 | 42 | 1 |
| Restic | partial model | 5 | 40 | 48 | 5 | 12 | 60 | 2 |

---

# 2. What improved

## etcd is the clearest success

Archive 7 rejected the whole model Architecture because one anchor ref carried
bad redundant metadata. Archive 9 publishes a partial model Architecture:

- server core;
- embedded server;
- storage;
- transport;
- HTTP handlers;
- client/tools;
- testing/support.

The status records the bad anchor as a diagnostic rather than erasing all
siblings. This is exactly the desired direction.

## Casdoor salvages cross-cutting participation

The model groups:

- application startup;
- certificate acquisition;
- startup providers;
- lifecycle interface.

The repeated local-remainder unit no longer automatically triggers a
whole-response failure.

## Product projection fixes are visible statically

The Archive 9 HTML shows these D230 changes:

- Architecture edges are passive (`cursor: default`, `pointer-events: none`);
- edge hit paths are hidden;
- ordinary wheel is no longer specified as the primary zoom action;
- inspector uses `overscroll-behavior: contain`;
- association wrapper and toggle are separated rather than nested buttons;
- mechanism source locations can render through a source action;
- Architecture diagnostics are more bounded than the old evidence wall.

These are meaningful improvements.

---

# 3. P0 — D230 over-salvage destroys useful roles

## Telebot

Input:

```text
u1 = local remainder · 2 symbols
u2 = telebot.v3 · 4 packages
```

Model proposes:

```text
Start bot       → u2 + lifecycle_start
Webhook handling→ u2 + request_dispatch_root
Middleware      → u1
Reactive UI     → u1
Layout          → u1
```

Current result:

```text
proposal.shared_unit_slice
proposal.empty_anchor_slice
proposal.empty_member_coverage
→ entire model proposal rejected
→ local package fallback
```

The likely mechanical reason is visible from the types:

```text
u2 members = packages
anchor members = symbols
package set ∩ symbol set = empty
```

The model’s roles are editorially plausible. They should not be treated as
exclusive package ownership, but they should not disappear.

## Chatto

Input:

```text
u1 = 42 local symbols
u2 = 42 internal packages
u3 = 2 top-level packages
u4 = 3 pkg packages
```

The model uses `u2` with distinct anchor families:

- admin control plane;
- config ingress;
- config apply;
- TLS/security;
- process entry;
- lifecycle interface.

Every one becomes empty under the same package/symbol slicing and the whole
semantic proposal is lost.

This is a severe regression in product information: the model discovered
meaningful responsibilities, but the validator tried to convert participation
into exclusive owned members.

## Restic

`u2 = internal · 48 packages` is reused by:

- command dispatcher;
- internal helpers.

One survives and the other is removed. The result is better than Archive 7’s
seven cloned owners, but still loses the cross-cutting/alternative role rather
than representing it honestly.

## Required correction

Separate three concepts:

```text
conceptual responsibility
shared unit participation
exclusive exact member ownership
```

A component may be useful with:

- a shared unit;
- a distinct anchor family;
- a distinct responsibility;
- no exclusive member slice.

Its UI must say:

```text
shared package scope
supported by exact lifecycle/config/security anchors
not exclusive ownership
```

Do not force a nonempty package↔symbol intersection.

---

# 4. P0 — unit granularity is still the upstream cause

Current broad units:

- Casdoor root: 34 packages;
- Telebot whole library: 4 packages;
- Chatto internal: 42 packages;
- Chatto remainder: 42 symbols;
- Restic internal: 48 packages.

The model cannot produce distinct owned components when its only legal choice is
one broad unit.

Required bounded adaptive splitting:

- stable path segment;
- source package;
- anchor family;
- module/application scope;
- bounded member-count/heterogeneity threshold;
- deterministic order and digest;
- explicit shared/unclassified remainder;
- no raw-member explosion.

The goal is not more units. It is enough discriminative units for meaningful
semantic choices.

---

# 5. P0 — Architecture prompt is overloaded

The current system prompt asks Flash to do all of these at once:

- invent local subsystem refs `g1`, `g2`;
- emit a flat alternating record order;
- repeat `subsystem_ref`;
- copy tagged `{kind,ref}` pairs;
- avoid duplicate refs;
- count distinct refs globally;
- self-check kinds;
- ensure one unit overall;
- preserve conceptual display order;
- decide cross-cutting participation;
- group architecture;
- name/describe everything.

Some requirements are backend bookkeeping, not semantic reasoning.

It also contains a confusing pair:

```text
never split one unit across components
```

and later:

```text
a unit may legitimately participate in several components
```

Even if the intended meanings differ, the model is asked to infer the
distinction.

Required response simplification:

- nested subsystem→components schema;
- plain `unit_refs` / `anchor_refs`;
- no model-supplied ref kind;
- no response-local subsystem IDs;
- no adjacency rule;
- no global self-check;
- no mandatory one-unit filler;
- temporary `distinguishing_feature` for sibling-relative labelling.

---

# 6. P0 — Navigator is being used as a checksum

Current Navigator model task:

```text
select one action_ref
+ echo its trail ref
+ echo both endpoint refs
+ echo every evidence ref
+ return empty arrays for irrelevant fields
```

The backend already owns:

```text
action_ref → trail → endpoints → evidence
```

A model should select the action; the backend should restore the rest.

Recommended output:

```json
{
  "version": 2,
  "catalog_ref": "...",
  "action_ref": "a7"
}
```

Optional editorial reason should be non-authoritative and only added if it has
visible product value.

This reduces failure surface and token use without weakening authority.

---

# 7. Theme prompts/validators: generally good, still too mechanical

## Scout strengths

- focused question;
- closed a*/f* refs;
- source refs are evidence, file refs are retrieval leads;
- item-local validation;
- overlong prose normalized;
- valid siblings survive.

## Scout defects

- duplicate anchor ref rejects the whole candidate;
- duplicate candidate detection rejects a later item but does not create a
  product-level equivalence group;
- “Propose 8–12 (valid 1–12)” is unnecessary target/minimum ambiguity;
- zero accepted candidates becomes stage failure rather than an explicit
  semantic-empty/local-question product state.

Recommended:

- exact duplicate refs normalize and count;
- target 8–12, explicitly allow fewer distinct themes;
- unknown required refs reject item;
- semantic duplicate themes coalesce after Adjudication;
- local questions remain visible when semantic output is empty.

## Adjudication strengths

- item-local;
- source-backed observation;
- overlong evidence normalized;
- direct/supporting/weak/irrelevant distinction;
- no runtime-order invention.

## Adjudication defects

- “every anchor must receive an assessment” is bookkeeping;
- duplicate assessment rejects the whole theme;
- weak/irrelevant assessments still require supported observation;
- one bad reading-order ref rejects the whole theme;
- model returns `role`, although backend already owns anchor role;
- zero accepted themes erases the semantic shelf.

Recommended:

- unassessed anchors become `unreviewed` locally and never publish;
- exact duplicate assessments normalize;
- supported observation required only for direct/supporting;
- invalid reading-order entries drop locally; accepted anchors remain;
- backend restores role;
- no-direct remains a rejected theme but stays diagnostic;
- zero accepted themes produces semantic-empty/local browse, not product loss.

---

# 8. Study portfolio remains weak

## Casdoor

Good integration/lifecycle themes, but the default shelf underrepresents core
IAM:

- login/session;
- users and organizations;
- authorization policies;
- identity linking;
- token lifecycle.

## etcd

The shelf still overweights:

- failure/testing;
- TLS;
- serialization;
- CLI/tools;
- internal HTTP;
- metrics.

Core areas should dominate when candidates exist:

- KV request;
- MVCC;
- Raft apply/commit;
- Watch;
- Lease;
- persistence lifecycle.

## Telebot

Remaining semantic overlaps:

- Raw/sendFiles error path versus Bot.Raw HTTP error;
- general error extraction versus verbose logging;
- file transfer versus media/file send family.

All exact readings should remain, but the default themes should coalesce.

## Restic

Release/docs/debug appear too early. Prefer:

- backup;
- restore;
- prune;
- repository lifecycle;
- snapshots;
- integrity/check;
- backends.

## Chatto

The strongest shelf in the matrix:

- config;
- TLS/security;
- auth providers;
- users/admin;
- storage;
- backup/restore;
- notifications.

Use Chatto as a positive comparison fixture.

---

# 9. Association and mechanism still need product correction

## Association

The exact package-equality fix is directionally correct, but the final product
still needs:

- witness precision separate from association scope;
- Boundary+Resource same-witness co-projection;
- broad/shared rows collapsed;
- list/map/inspector count reconciliation;
- no relation edge from observed-in-scope alone.

## Mechanism

Archive 9 improves Casdoor to three listed transitions, but the schema still
has no explicit source and target on every transition.

Casdoor shows:

```text
entry main
handoff ldap.getTLSconfig
handoff service.Start
unknown
```

The array can still be read as:

```text
main → ldap.getTLSconfig → service.Start
```

This order is not established.

etcd still carries 51 transition-like rows, many of which are independent
boundary/resource observations, including test/tool packages and blank
“surface” labels.

Required:

- explicit endpoint graph;
- connected fragments only;
- independent handoffs separate;
- boundary/resource observations as touchpoint groups;
- production/test/tooling filtering in default mechanism;
- exact source actions;
- no ordinal-as-path semantics.

---

# 10. UI review status

A complete real-pointer browser review was not possible in this review runtime:
local `file://` and localhost navigation were blocked. Therefore this document
does not claim a real interaction PASS.

Static inspection confirms several D230 fixes:

- passive edges;
- hidden edge hit paths;
- association toggle separated from witness actions;
- inspector overscroll containment;
- bounded Architecture sections;
- source-action projection in more places.

Hermes must still run the real desktop interaction matrix:

- node hit-testing after initial layout and Fit;
- normal wheel page scroll;
- Ctrl/Cmd-wheel zoom;
- pan from blank canvas only;
- inspector focus enter/return;
- source-looking text actionable or explicitly unavailable;
- Back/scroll/selection restoration;
- 1280×800, 1440×1000, 1920×1080;
- 125% and 150% zoom.

The older report baseline clearly showed why static CSS inspection alone was
insufficient: interactive edges, broad evidence projection and hidden
interaction contradictions were present even when the report rendered.

---

# 11. Priority verdict

## P0

Architecture semantic boundary:

- simplify prompt/schema;
- represent shared participation;
- remove type-blind package↔symbol slicing;
- adaptive units;
- preserve D229 item-local salvage;
- version/cache/replay correctly.

## P1

Simplify Navigator and Theme bookkeeping:

- selection-only Navigator;
- duplicate normalization;
- backend-owned kind/role/order accounting;
- semantic-empty state.

## P2

Study portfolio:

- equivalence grouping;
- Architecture-area coverage;
- core-first ordering;
- preserve full shelf.

## P3

Product projection:

- association co-projection;
- connected mechanism graph;
- list-first complete view;
- secondary map;
- real desktop interaction acceptance.

## Not now

- new analyzer;
- new semantic stage;
- strict-tool-call migration;
- BPMN/C4;
- mobile;
- more prompt commandments;
- retry/tuning loop.
