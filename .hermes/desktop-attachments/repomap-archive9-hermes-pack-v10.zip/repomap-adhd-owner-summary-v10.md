# Repomap next work — ADHD owner summary v10

## NOW — only three things

### 1. Fix the Architecture semantic boundary

The old duplicate catastrophe is mostly fixed.

The new bug:

```text
shared package unit + distinct symbol anchors
→ backend tries to make an exclusive intersection
→ intersection is empty
→ useful Telebot/Chatto roles disappear
```

Target:

```text
shared participation survives
exclusive ownership stays honest
valid siblings never disappear
```

### 2. Stop making the model do bookkeeping

Cut from model contracts:

- ordering/adjacency mechanics;
- unique checks;
- ref-kind echo;
- global coverage arithmetic;
- Navigator evidence echo;
- exhaustive assessment of every unused anchor.

Model does:

```text
choose / group / name / explain / judge
```

Backend does:

```text
dedupe / kind / order / IDs / counts / restore / validate / publish
```

### 3. Make the product teach core behavior

After Architecture is stable:

- merge duplicate Study themes without losing readings;
- core behavior before tooling;
- exact association scope;
- Boundary+Resource one user row;
- connected mechanism fragments only;
- list is complete truth; diagram is a useful projection.

## NOT NOW

- mobile;
- BPMN/C4;
- Tree-sitter/new language;
- third model call;
- strict-tool-call migration;
- another prompt full of “never / count / self-check”;
- retry/tuning loop.

## Morning success test

You should be able to open five reports and say:

```text
Telebot/Chatto model meaning survived.
etcd stayed accepted_partial.
Restic no longer clones/erases one broad unit.
Study starts with the repository's core.
Every diagram edge/path is honest.
Nothing exact disappeared.
```
