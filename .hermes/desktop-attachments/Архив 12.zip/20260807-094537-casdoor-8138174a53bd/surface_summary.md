# Runtime surfaces

Repository: `/Users/dvordrova/git/casdoor`

Scenario: `go:darwin/amd64:tags=`

Discovered 18 static surface record(s): 4 direct, 14 wrapper-derived.

This is not a runtime trace. exact build-selected process entries, typed Cobra commands, runtime registrations and starts found through safe typed package closures, bounded wrapper propagation, and the generic typed registration detector (path string + handler) under the recorded build scenario, subject to listed diagnostics and frontiers.

## Discovery phases

- `package_load`: 1966 ms (34/34) — loading build-selected packages and dependency type information
- `ssa_build`: 347 ms (34/34) — building SSA for repository packages with dependency type information
- `call_graph`: 1178 ms (90395/90395) — indexing all SSA functions and constructing one CHA call graph
- `candidate_index`: 1377 ms (90395/90395) — indexing call targets and bounded wrapper candidates
- `cobra_inventory`: 89 ms — inventorying build-selected typed Cobra descriptors and direct relationships
- `architecture_anchors`: 1086 ms (13/13) — projecting existing exact architecture anchors
- `entrypoint_walk`: 61 ms (1/1) — walking build-selected executable entrypoints
- `detached_walk`: 129 ms (586/1500) — recovering import-reachable registrations with unresolved entry dispatch
- `catalog_finalize`: 0 ms (18/18) — deduplicating surfaces and deriving presentation semantics
- `grounding_finalize`: 0 ms (13/13) — finalizing existing architecture grounding

## result of strings.TrimSpace

- ID: `trigger-071769a15ed686cc2064182b`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `github.com/casdoor/casdoor`; role `primary_application`; availability `available`
- Handler: `github.com/casdoor/casdoor/scan.evalVersionRule$1`
- Dispatcher: `typed registration receiver`
- Registration: `scan/util.go:394` via `typed_registration_detector`
- Wrapper chain: `github.com/casdoor/casdoor/scan.(SecurityScanProvider).Scan` → `github.com/casdoor/casdoor/scan.filterMatchedCVEs` → `github.com/casdoor/casdoor/scan.evalVersionRule`
- Frontiers: dynamic_route_identity: result of strings.TrimSpace; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## application_context

- ID: `trigger-0940f85871922195e5fc70f1`
- Status: `confirmed_typed_registration`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `github.com/casdoor/casdoor`; role `primary_application`; availability `available`
- Handler: `github.com/casdoor/casdoor/pp.Pay$1`
- Dispatcher: `typed registration receiver`
- Registration: `pp/paypal.go:67` via `typed_registration_detector`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## HTTP server

- ID: `trigger-123e85d17163077e23e1195a`
- Status: `confirmed_server_start_call`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact server start can seed a partial operational trace; accept and dispatch order remain unresolved
- Executable: `github.com/casdoor/casdoor`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `unresolved value`
- Registration: `service/proxy.go:367` via `net-http-server-listen-and-serve-tls`
- Server start: `service/proxy.go:367`
- Wrapper chain: `github.com/casdoor/casdoor/service.Start` → `github.com/casdoor/casdoor/service.Start$2`

## payer

- ID: `trigger-1f3f38ff5333b0e5440ececb`
- Status: `confirmed_typed_registration`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `github.com/casdoor/casdoor`; role `primary_application`; availability `available`
- Handler: `github.com/casdoor/casdoor/pp.Pay$2`
- Dispatcher: `typed registration receiver`
- Registration: `pp/wechatpay.go:85` via `typed_registration_detector`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## routes assembled from runtime configuration

- ID: `trigger-2573d9cab68e0350a9d04d74`
- Status: `configured_route_inventory_unresolved`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: dynamic frontier has no exact executable entry to seed a trace
- Executable: `github.com/casdoor/casdoor`; role `primary_application`; availability `available`
- Handler: `configuration-selected handlers`
- Dispatcher: `beego-namespace`
- Registration: `routers/router.go:33` via `beego-web-newnamespace`
- Wrapper chain: `github.com/casdoor/casdoor/routers.InitAPI`
- Frontiers: configuration_assembled_route_inventory: Routes are assembled from runtime configuration; static analysis did not invent or enumerate them.

## routes assembled from runtime configuration

- ID: `trigger-3e514266322701f888a2b3da`
- Status: `configured_route_inventory_unresolved`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: dynamic frontier has no exact executable entry to seed a trace
- Executable: `github.com/casdoor/casdoor`; role `primary_application`; availability `available`
- Handler: `configuration-selected handlers`
- Dispatcher: `beego-namespace`
- Registration: `routers/router.go:35` via `beego-web-nsinclude`
- Wrapper chain: `github.com/casdoor/casdoor/routers.InitAPI`
- Frontiers: configuration_assembled_route_inventory: Routes are assembled from runtime configuration; static analysis did not invent or enumerate them.

## unresolved value

- ID: `trigger-455919ec132d4318a30bd9e7`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `github.com/casdoor/casdoor`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `unresolved value`
- Registration: `service/proxy.go:308` via `net-http-servemux-handlefunc`
- Server start: `service/proxy.go:367`
- Wrapper chain: `github.com/casdoor/casdoor/service.Start`
- Frontiers: dynamic_handler_identity: unresolved value; dynamic_route_identity: unresolved value

## routes assembled from runtime configuration

- ID: `trigger-46bab751e7c0ca459150c20c`
- Status: `configured_route_inventory_unresolved`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: dynamic frontier has no exact executable entry to seed a trace
- Executable: `github.com/casdoor/casdoor`; role `primary_application`; availability `available`
- Handler: `configuration-selected handlers`
- Dispatcher: `beego-namespace`
- Registration: `routers/router.go:40` via `beego-web-nsinclude`
- Wrapper chain: `github.com/casdoor/casdoor/routers.InitAPI`
- Frontiers: configuration_assembled_route_inventory: Routes are assembled from runtime configuration; static analysis did not invent or enumerate them.

## github.com/casdoor/casdoor/scan.splitAndTrim$1

- ID: `trigger-594d40fdab6a5fdad8421482`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `github.com/casdoor/casdoor`; role `primary_application`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `scan/intranet_server.go:222` via `typed_registration_detector`
- Wrapper chain: `github.com/casdoor/casdoor/scan.parseIntranetScanRequest` → `github.com/casdoor/casdoor/scan.parseListField` → `github.com/casdoor/casdoor/scan.splitAndTrim`
- Frontiers: dynamic_handler_identity: unknown handler; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## unresolved value

- ID: `trigger-59bebf461b1cc322bc69a78d`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `github.com/casdoor/casdoor`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `unresolved value`
- Registration: `service/proxy.go:309` via `net-http-servemux-handlefunc`
- Server start: `service/proxy.go:367`
- Wrapper chain: `github.com/casdoor/casdoor/service.Start`
- Frontiers: dynamic_handler_identity: unresolved value; dynamic_route_identity: unresolved value

## HTTP server

- ID: `trigger-5f4a7d4c4f7e7e6306773095`
- Status: `confirmed_server_start_call`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact server start can seed a partial operational trace; accept and dispatch order remain unresolved
- Executable: `github.com/casdoor/casdoor`; role `primary_application`; availability `available`
- Handler: `net/http.DefaultServeMux`
- Dispatcher: `net/http.DefaultServeMux`
- Registration: `service/proxy.go:323` via `net-http-listen-and-serve`
- Server start: `service/proxy.go:323`
- Wrapper chain: `github.com/casdoor/casdoor/service.Start` → `github.com/casdoor/casdoor/service.Start$1`
- Frontiers: unresolved_dispatch_inventory: No supported route registration was correlated with this static server start call.

## result of fmt.Sprintf

- ID: `trigger-6851652013aae58ca9ee2ca1`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `github.com/casdoor/casdoor`; role `primary_application`; availability `available`
- Handler: `github.com/casdoor/casdoor/object.addSyncerJob$1`
- Dispatcher: `typed registration receiver`
- Registration: `object/syncer_cron.go:73` via `typed_registration_detector`
- Wrapper chain: `github.com/casdoor/casdoor/object.RunSyncUsersJob` → `github.com/casdoor/casdoor/object.addSyncerJob`
- Frontiers: dynamic_route_identity: result of fmt.Sprintf; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## amount

- ID: `trigger-a05f408f4d819e4b2b0d66e7`
- Status: `confirmed_typed_registration`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `github.com/casdoor/casdoor`; role `primary_application`; availability `available`
- Handler: `github.com/casdoor/casdoor/pp.Pay$1`
- Dispatcher: `typed registration receiver`
- Registration: `pp/wechatpay.go:76` via `typed_registration_detector`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## routes assembled from runtime configuration

- ID: `trigger-cab42c22b3526899146f08f4`
- Status: `configured_route_inventory_unresolved`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: dynamic frontier has no exact executable entry to seed a trace
- Executable: `github.com/casdoor/casdoor`; role `primary_application`; availability `available`
- Handler: `configuration-selected handlers`
- Dispatcher: `beego-namespace`
- Registration: `routers/router.go:39` via `beego-web-nsnamespace`
- Wrapper chain: `github.com/casdoor/casdoor/routers.InitAPI`
- Frontiers: configuration_assembled_route_inventory: Routes are assembled from runtime configuration; static analysis did not invent or enumerate them.

## main

- ID: `trigger-d0ffcc169913e9701cc401c2`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a partial trace; downstream runtime handoff remains unresolved
- Executable: `github.com/casdoor/casdoor`; role `primary_application`; availability `available`
- Handler: `github.com/casdoor/casdoor.main`
- Dispatcher: `process entry`
- Registration: `main.go:36` via `gofacts-go-main`

## unresolved value

- ID: `trigger-e39643d448a915c6f7e43e7c`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `github.com/casdoor/casdoor`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `typed registration receiver`
- Registration: `object/token_cleanup.go:79` via `typed_registration_detector`
- Wrapper chain: `github.com/casdoor/casdoor/object.InitCleanupTokens`
- Frontiers: dynamic_handler_identity: unresolved value; dynamic_route_identity: unresolved value

## unresolved value

- ID: `trigger-e48821e4c88d2611d0a6c1bb`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `github.com/casdoor/casdoor`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `typed registration receiver`
- Registration: `object/syncer_cron.go:73` via `typed_registration_detector`
- Wrapper chain: `github.com/casdoor/casdoor/object.InitFromFile` → `github.com/casdoor/casdoor/object.initDefinedSyncer` → `github.com/casdoor/casdoor/object.AddSyncer` → `github.com/casdoor/casdoor/object.addSyncerJob`
- Frontiers: dynamic_handler_identity: unresolved value; dynamic_route_identity: unresolved value

## routes assembled from runtime configuration

- ID: `trigger-f661682ec5e1c708461c5a51`
- Status: `configured_route_inventory_unresolved`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: dynamic frontier has no exact executable entry to seed a trace
- Executable: `github.com/casdoor/casdoor`; role `primary_application`; availability `available`
- Handler: `configuration-selected handlers`
- Dispatcher: `beego-namespace`
- Registration: `routers/router.go:34` via `beego-web-nsnamespace`
- Wrapper chain: `github.com/casdoor/casdoor/routers.InitAPI`
- Frontiers: configuration_assembled_route_inventory: Routes are assembled from runtime configuration; static analysis did not invent or enumerate them.

Budgets reached: `value_depth`, `value_description`, `value_evaluation`, `value_evaluation_cycle`.
