# repomap onboarding feedback

Repository: github.com/casdoor/casdoor
Direction followed:
First useful file:
Time to useful orientation:

## Correct

-

## Missing

-

## Misleading

-
