# Runtime surfaces

Repository: `/Users/dvordrova/git/etcd`

Scenario: `go:darwin/amd64:tags=`

Discovered 129 static surface record(s): 59 direct, 70 wrapper-derived.

Cobra inventory: 36 descriptor(s), 28 exact binding(s), 8 exact activation(s), 24 partial relation(s), 0 duplicate relation(s), 36 retained record(s), 0 dropped record(s).

This is not a runtime trace. exact build-selected process entries, typed Cobra commands, runtime registrations and starts found through safe typed package closures, bounded wrapper propagation, and the generic typed registration detector (path string + handler) under the recorded build scenario, subject to listed diagnostics and frontiers.

## Discovery phases

- `package_load`: 10511 ms (183/183) — loading build-selected packages and dependency type information
- `ssa_build`: 1844 ms (183/183) — building SSA for repository packages with dependency type information
- `call_graph`: 2249 ms (64262/64262) — indexing all SSA functions and constructing one CHA call graph
- `candidate_index`: 1597 ms (64262/64262) — indexing call targets and bounded wrapper candidates
- `cobra_inventory`: 22 ms (36/36) — inventorying build-selected typed Cobra descriptors and direct relationships
- `architecture_anchors`: 483 ms (149/149) — projecting existing exact architecture anchors
- `entrypoint_walk`: 65 ms (18/18) — walking build-selected executable entrypoints
- `detached_walk`: 33 ms (1248/1500) — recovering import-reachable registrations with unresolved entry dispatch
- `catalog_finalize`: 7 ms (129/129) — deduplicating surfaces and deriving presentation semantics
- `grounding_finalize`: 1 ms (57/57) — finalizing existing architecture grounding

## go.etcd.io/etcd/tests/v3/antithesis/test-template/robustness/traffic.runTraffic$2

- ID: `trigger-00b2f356c67044ca2d9e26da`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `tests/antithesis/test-template/robustness/traffic`; role `test_or_helper`; availability `available`
- Handler: `go.etcd.io/etcd/tests/v3/antithesis/test-template/robustness/traffic.runTraffic$2`
- Dispatcher: `*golang.org/x/sync/errgroup.Group@tests/antithesis/test-template/robustness/traffic/main.go:103:2`
- Registration: `tests/antithesis/test-template/robustness/traffic/main.go:115` via `x-sync-errgroup-go`
- Wrapper chain: `go.etcd.io/etcd/tests/v3/antithesis/test-template/robustness/traffic.runTraffic`

## go.etcd.io/etcd/server/v3/etcdserver.run$6

- ID: `trigger-04fe07d390d49603dd311dea`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `tools/etcd-dump-metrics`; role `tooling`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `server/etcdserver/server.go:840` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/v3/tools/etcd-dump-metrics.main$4` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/etcdserver.(*EtcdServer).Start` → `go.etcd.io/etcd/server/v3/etcdserver.(*EtcdServer).start` → `go.etcd.io/etcd/server/v3/etcdserver.(*EtcdServer).run`
- Frontiers: dynamic_handler_identity: unknown handler

## go.etcd.io/etcd/server/v3/etcdserver/api/rafthttp.ProbingPrefix

- ID: `trigger-096947de658623da1610458b`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `contrib/raftexample`; role `test_or_helper`; availability `available`
- Handler: `result of github.com/xiang90/probing.NewHandler`
- Dispatcher: `net/http.NewServeMux@server/etcdserver/api/rafthttp/transport.go:161:25`
- Registration: `server/etcdserver/api/rafthttp/transport.go:165` via `net-http-servemux-handle`
- Wrapper chain: `go.etcd.io/etcd/v3/contrib/raftexample.newRaftNode` → `go.etcd.io/etcd/v3/contrib/raftexample.(*raftNode).startRaft` → `go.etcd.io/etcd/v3/contrib/raftexample.(*raftNode).serveRaft` → `go.etcd.io/etcd/server/v3/etcdserver/api/rafthttp.(*Transport).Handler`
- Frontiers: dynamic_handler_identity: result of github.com/xiang90/probing.NewHandler

## result of path.Split

- ID: `trigger-09d21c08e8b3eee15bb8b91e`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `etcdutl`; role `tooling`; availability `available`
- Handler: `go.etcd.io/etcd/server/v3/etcdserver/api/v2store.checkDir`
- Dispatcher: `typed registration receiver`
- Registration: `server/etcdserver/api/v2store/store.go:591` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdserver/api/v2store.(*store).internalCreate`
- Frontiers: dynamic_route_identity: result of path.Split; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## go.etcd.io/etcd/server/v3/storage/mvcc.compactBarrier$1

- ID: `trigger-0b589eb603037688608122a5`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `etcdutl`; role `tooling`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `server/storage/mvcc/kvstore.go:147` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/server/v3/storage/mvcc.(*store).compactBarrier`
- Frontiers: dynamic_handler_identity: unknown handler; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## watch-get

- ID: `trigger-0eaac8d3b1dbdeb4bb3f4f61`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/v3/tools/benchmark/cmd.watchGetFunc`
- Dispatcher: `go.etcd.io/etcd/v3/tools/benchmark/cmd.init#11`
- Registration: `tools/benchmark/cmd/watch_get.go:46` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## migrate

- ID: `trigger-107286aebed429cb8f648de5`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/etcdutl/v3/etcdutl.func_literal@etcdutl/etcdutl/migrate_command.go:39:8`
- Dispatcher: `go.etcd.io/etcd/etcdutl/v3.init#1`
- Registration: `etcdutl/ctl.go:44` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## main

- ID: `trigger-10f63d90bf9006b03a9133a0`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a partial trace; downstream runtime handoff remains unresolved
- Executable: `contrib/lock/storage`; role `test_or_helper`; availability `available`
- Handler: `go.etcd.io/etcd/v3/contrib/lock/storage.main`
- Dispatcher: `process entry`
- Registration: `contrib/lock/storage/storage.go:104` via `gofacts-go-main`

## /proxy/metrics

- ID: `trigger-114194fd7f31ec7b19d10bd8`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `result of github.com/prometheus/client_golang/prometheus/promhttp.Handler`
- Dispatcher: `net/http.NewServeMux@server/etcdmain/grpc_proxy.go:604:26`
- Registration: `server/proxy/grpcproxy/metrics.go:105` via `net-http-servemux-handle`
- Wrapper chain: `go.etcd.io/etcd/server/v3/proxy/grpcproxy.HandleProxyMetrics`
- Frontiers: dynamic_handler_identity: result of github.com/prometheus/client_golang/prometheus/promhttp.Handler; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## unresolved value

- ID: `trigger-138c815c887f8d6487390d1e`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `unresolved value`
- Registration: `server/etcdserver/api/etcdhttp/peer.go:63` via `net-http-servemux-handlefunc`
- Server start: `server/embed/etcd.go:605`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.(*Etcd).servePeers` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.NewPeerHandler` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.newPeerHandler`
- Frontiers: dynamic_handler_identity: unresolved value; dynamic_route_identity: unresolved value

## main

- ID: `trigger-143b06f09a8ddfc5eeef2b60`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a partial trace; downstream runtime handoff remains unresolved
- Executable: `tools/etcd-dump-metrics`; role `tooling`; availability `available`
- Handler: `go.etcd.io/etcd/v3/tools/etcd-dump-metrics.main`
- Dispatcher: `process entry`
- Registration: `tools/etcd-dump-metrics/main.go:43` via `gofacts-go-main`

## /

- ID: `trigger-159fb5899686569243a798ac`
- Status: `confirmed_through_repository_wrapper`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `net/http.NotFound`
- Dispatcher: `net/http.NewServeMux@server/etcdmain/grpc_proxy.go:564:29`
- Registration: `server/etcdmain/grpc_proxy.go:565` via `net-http-servemux-handlefunc`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.mustHTTPServer`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## unresolved value

- ID: `trigger-1750206950e76f8a37e7aecc`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `unresolved value`
- Registration: `server/etcdserver/api/etcdhttp/peer.go:76` via `net-http-servemux-handle`
- Server start: `server/embed/etcd.go:605`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.(*Etcd).servePeers` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.NewPeerHandler` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.newPeerHandler`
- Frontiers: dynamic_handler_identity: unresolved value; dynamic_route_identity: unresolved value

## scan-keys

- ID: `trigger-17edecb7d104fdb74f122d58`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/v3/tools/etcd-dump-db.scanKeysCommandFunc`
- Dispatcher: `go.etcd.io/etcd/v3/tools/etcd-dump-db.init#1`
- Registration: `tools/etcd-dump-db/main.go:71` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## go.etcd.io/etcd/server/v3/storage/mvcc.compact$1

- ID: `trigger-1a808d256019213586c1761c`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `etcdutl`; role `tooling`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `server/storage/mvcc/kvstore.go:236` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/server/v3/storage/mvcc.(*store).compact`
- Frontiers: dynamic_handler_identity: unknown handler; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## HTTP server

- ID: `trigger-1ef308166fd3ab0528b27fc6`
- Status: `confirmed_server_start_call`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact server start can seed a partial operational trace; accept and dispatch order remain unresolved
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unknown`
- Dispatcher: `unknown`
- Registration: `server/embed/serve.go:278` via `net-http-server-serve`
- Server start: `server/embed/serve.go:278`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved; unresolved_dispatch_inventory: No supported route registration was correlated with this static server start call.

## snapshot status

- ID: `trigger-1f1df4a82097434c5fc225c5`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/etcdutl/v3/etcdutl.SnapshotStatusCommandFunc`
- Dispatcher: `go.etcd.io/etcd/etcdutl/v3/etcdutl.NewSnapshotCommand`
- Registration: `etcdutl/etcdutl/snapshot_command.go:54` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## main

- ID: `trigger-20d6857577f88e56d74f0490`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a partial trace; downstream runtime handoff remains unresolved
- Executable: `etcdctl`; role `secondary_service`; availability `available`
- Handler: `go.etcd.io/etcd/etcdctl/v3.main`
- Dispatcher: `process entry`
- Registration: `etcdctl/main.go:22` via `gofacts-go-main`

## go.etcd.io/etcd/server/v3/etcdserver/api/rafthttp.RaftStreamPrefix/

- ID: `trigger-25319a37754c4c062da3adeb`
- Status: `confirmed_through_repository_wrapper`; certainty `static`; resolution `ambiguous`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `contrib/raftexample`; role `test_or_helper`; availability `available`
- Handler: `*go.etcd.io/etcd/server/v3/etcdserver/api/rafthttp.streamHandler@server/etcdserver/api/rafthttp/http.go:336:21`
- Dispatcher: `net/http.NewServeMux@server/etcdserver/api/rafthttp/transport.go:161:25`
- Registration: `server/etcdserver/api/rafthttp/transport.go:163` via `net-http-servemux-handle`
- Wrapper chain: `go.etcd.io/etcd/v3/contrib/raftexample.newRaftNode` → `go.etcd.io/etcd/v3/contrib/raftexample.(*raftNode).startRaft` → `go.etcd.io/etcd/v3/contrib/raftexample.(*raftNode).serveRaft` → `go.etcd.io/etcd/server/v3/etcdserver/api/rafthttp.(*Transport).Handler`

## main

- ID: `trigger-258a36c6c856d2c28c87253f`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a partial trace; downstream runtime handoff remains unresolved
- Executable: `tools/proto-annotations`; role `tooling`; availability `available`
- Handler: `go.etcd.io/etcd/v3/tools/proto-annotations.main`
- Dispatcher: `process entry`
- Registration: `tools/proto-annotations/main.go:24` via `gofacts-go-main`

## /metrics

- ID: `trigger-2709cc24a1bfb1f432b052ac`
- Status: `confirmed_through_repository_wrapper`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `go.etcd.io/etcd/server/v3/proxy/grpcproxy.HandleMetrics$1`
- Dispatcher: `net/http.NewServeMux@server/etcdmain/grpc_proxy.go:564:29`
- Registration: `server/proxy/grpcproxy/metrics.go:81` via `net-http-servemux-handlefunc`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.mustHTTPServer` → `go.etcd.io/etcd/server/v3/proxy/grpcproxy.HandleMetrics`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## put

- ID: `trigger-28b39ecd2ed94d594fd5c0c7`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/v3/tools/benchmark/cmd.putFunc`
- Dispatcher: `go.etcd.io/etcd/v3/tools/benchmark/cmd.init#4`
- Registration: `tools/benchmark/cmd/put.go:61` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## go.etcd.io/etcd/server/v3/embed.setupLogRotation$1

- ID: `trigger-2e87e0097d2b9805276b0f68`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `server/embed/config_logging.go:283` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/server/v3/embed.(*Config).setupLogging` → `go.etcd.io/etcd/server/v3/embed.setupLogRotation`
- Frontiers: dynamic_handler_identity: unknown handler; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## testgrid-analysis

- ID: `trigger-30bb76efd2a389c0fef8dff7`
- Status: `partial_cobra_activation`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command activation can seed a partial path; child dispatch and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `Run/RunE descriptor initializer unresolved`
- Dispatcher: `no exact shallow registration or activation`
- Registration: unresolved via `cobra-command-activation`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## unresolved value

- ID: `trigger-3357ea5656e51734aa4a13a7`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `unresolved value`
- Registration: `server/etcdserver/api/etcdhttp/peer.go:78` via `net-http-servemux-handlefunc`
- Server start: `server/embed/etcd.go:605`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.(*Etcd).servePeers` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.NewPeerHandler` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.newPeerHandler`
- Frontiers: dynamic_handler_identity: unresolved value; dynamic_route_identity: unresolved value

## main

- ID: `trigger-34f57042befdb39d87c29b4b`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a partial trace; downstream runtime handoff remains unresolved
- Executable: `tools/local-tester/bridge`; role `tooling`; availability `available`
- Handler: `go.etcd.io/etcd/v3/tools/local-tester/bridge.main`
- Dispatcher: `process entry`
- Registration: `tools/local-tester/bridge/bridge.go:196` via `gofacts-go-main`

## go.etcd.io/etcd/server/v3/storage/mvcc.updateCompactRev$1

- ID: `trigger-384fc08aca4b6cdf0e1a2a17`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `etcdutl`; role `tooling`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `server/storage/mvcc/kvstore.go:201` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/server/v3/storage/mvcc.(*store).updateCompactRev`
- Frontiers: dynamic_handler_identity: unknown handler; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## /proxy/health

- ID: `trigger-3a91fdc3c82f54340145ae41`
- Status: `confirmed_through_repository_wrapper`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.NewHealthHandler$1`
- Dispatcher: `net/http.NewServeMux@server/etcdmain/grpc_proxy.go:604:26`
- Registration: `server/proxy/grpcproxy/health.go:46` via `net-http-servemux-handle`
- Wrapper chain: `go.etcd.io/etcd/server/v3/proxy/grpcproxy.HandleProxyHealth`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## result of path.Join

- ID: `trigger-3b72afd14118f1fd0ef84bcb`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.newHealthHandler$1`
- Dispatcher: `parameter mux`
- Registration: `server/etcdserver/api/etcdhttp/health.go:292` via `net-http-servemux-handle`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.(*CheckRegistry).InstallHTTPEndpoints`
- Frontiers: dynamic_route_identity: result of path.Join; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## main

- ID: `trigger-3bb865b15e355ec519235be4`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a partial trace; downstream runtime handoff remains unresolved
- Executable: `tools/etcd-dump-db`; role `tooling`; availability `available`
- Handler: `go.etcd.io/etcd/v3/tools/etcd-dump-db.main`
- Dispatcher: `process entry`
- Registration: `tools/etcd-dump-db/main.go:75` via `gofacts-go-main`

## result of path.Clean

- ID: `trigger-3d847e98259b02a3f0c6252f`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `etcdutl`; role `tooling`; availability `available`
- Handler: `go.etcd.io/etcd/server/v3/etcdserver/api/v2store.internalGet$1`
- Dispatcher: `typed registration receiver`
- Registration: `server/etcdserver/api/v2store/store.go:666` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdserver/api/v2store.(*store).internalGet`
- Frontiers: dynamic_route_identity: result of path.Clean; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## unresolved value

- ID: `trigger-3f131453aa758a4c5494deef`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `unresolved value`
- Registration: `server/etcdserver/api/etcdhttp/health.go:292` via `net-http-servemux-handle`
- Server start: `server/embed/etcd.go:605`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.(*Etcd).serveClients` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.HandleHealth` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.installLivezEndpoints` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.(*CheckRegistry).InstallHTTPEndpoints`
- Frontiers: dynamic_handler_identity: unresolved value; dynamic_route_identity: unresolved value

## unresolved value

- ID: `trigger-40da5b8e7c27075cdd99a62e`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `server/etcdserver/server.go:840` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/etcdserver.(*EtcdServer).Start` → `go.etcd.io/etcd/server/v3/etcdserver.(*EtcdServer).start` → `go.etcd.io/etcd/server/v3/etcdserver.(*EtcdServer).run`
- Frontiers: dynamic_handler_identity: unknown handler; dynamic_route_identity: unresolved value

## unresolved value

- ID: `trigger-439bfed00381c1524e50bc01`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `unresolved value`
- Registration: `server/etcdserver/api/etcdhttp/metrics.go:30` via `net-http-servemux-handle`
- Server start: `server/embed/etcd.go:605`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.(*Etcd).serveClients` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.HandleMetrics`
- Frontiers: dynamic_handler_identity: unresolved value; dynamic_route_identity: unresolved value

## hashkv

- ID: `trigger-442e3458853910d0823a8803`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/etcdutl/v3/etcdutl.hashKVCommandFunc`
- Dispatcher: `go.etcd.io/etcd/etcdutl/v3.init#1`
- Registration: `etcdutl/ctl.go:44` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## main

- ID: `trigger-4578b42321004690bff900e4`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a partial trace; downstream runtime handoff remains unresolved
- Executable: `tests/antithesis/test-template/entrypoint`; role `test_or_helper`; availability `available`
- Handler: `go.etcd.io/etcd/tests/v3/antithesis/test-template/entrypoint.main`
- Dispatcher: `process entry`
- Registration: `tests/antithesis/test-template/entrypoint/main.go:70` via `gofacts-go-main`

## stm

- ID: `trigger-4a8dff6cac2153311082cc2a`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/v3/tools/benchmark/cmd.stmFunc`
- Dispatcher: `go.etcd.io/etcd/v3/tools/benchmark/cmd.init#7`
- Registration: `tools/benchmark/cmd/stm.go:60` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## gateway

- ID: `trigger-4ad1198674dfc40b63d266ad`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `Run/RunE descriptor initializer unresolved`
- Dispatcher: `go.etcd.io/etcd/server/v3/etcdmain.init#1`
- Registration: `server/etcdmain/gateway.go:48` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## etcd-dump-db

- ID: `trigger-4ce04db9c23fda0ab9c768c2`
- Status: `partial_cobra_activation`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command activation can seed a partial path; child dispatch and downstream effects remain unresolved
- Executable: `tools/etcd-dump-db`; role `tooling`; availability `available`
- Handler: `Run/RunE descriptor initializer unresolved`
- Dispatcher: `no exact shallow registration or activation`
- Registration: unresolved via `cobra-command-activation`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## go.etcd.io/etcd/server/v3/storage/mvcc.updateCompactRev$1

- ID: `trigger-4dae93e00dd8f957fd48d4fb`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `tools/etcd-dump-metrics`; role `tooling`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `server/storage/mvcc/kvstore.go:201` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/v3/tools/etcd-dump-metrics.main$4` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/etcdserver.NewServer` → `go.etcd.io/etcd/server/v3/storage/mvcc.New` → `go.etcd.io/etcd/server/v3/storage/mvcc.newWatchableStore` → `go.etcd.io/etcd/server/v3/storage/mvcc.NewStore` → `go.etcd.io/etcd/server/v3/storage/mvcc.(*store).restore` → `go.etcd.io/etcd/server/v3/storage/mvcc.(*store).compactLockfree` → `go.etcd.io/etcd/server/v3/storage/mvcc.(*store).updateCompactRev`
- Frontiers: dynamic_handler_identity: unknown handler

## gateway start

- ID: `trigger-4e0694630afe14dc24ceac57`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/server/v3/etcdmain.startGateway`
- Dispatcher: `go.etcd.io/etcd/server/v3/etcdmain.newGatewayCommand`
- Registration: `server/etcdmain/gateway.go:57` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## main

- ID: `trigger-4f9f8606d9312a4c5fea0312`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a partial trace; downstream runtime handoff remains unresolved
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `go.etcd.io/etcd/server/v3.main`
- Dispatcher: `process entry`
- Registration: `server/main.go:30` via `gofacts-go-main`

## lease-keepalive

- ID: `trigger-50f43de9401c1eef0e40f6b7`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/v3/tools/benchmark/cmd.leaseKeepaliveFunc`
- Dispatcher: `go.etcd.io/etcd/v3/tools/benchmark/cmd.init#1`
- Registration: `tools/benchmark/cmd/lease.go:39` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## go.etcd.io/etcd/server/v3/etcdserver.run$6

- ID: `trigger-515213f9e22929622fe562b0`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `etcdutl`; role `tooling`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `server/etcdserver/server.go:840` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdserver.(*EtcdServer).run`
- Frontiers: dynamic_handler_identity: unknown handler; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## /proxy/health

- ID: `trigger-547223954a14c4ee8188055d`
- Status: `confirmed_through_repository_wrapper`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.NewHealthHandler$1`
- Dispatcher: `net/http.NewServeMux@server/etcdmain/grpc_proxy.go:564:29`
- Registration: `server/proxy/grpcproxy/health.go:46` via `net-http-servemux-handle`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.mustHTTPServer` → `go.etcd.io/etcd/server/v3/proxy/grpcproxy.HandleProxyHealth`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## next t9

- ID: `trigger-5549b9449a653fb1dfdf4d13`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `next t9`
- Dispatcher: `net/http.NewServeMux@server/etcdmain/grpc_proxy.go:564:29`
- Registration: `server/etcdmain/grpc_proxy.go:572` via `net-http-servemux-handle`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.mustHTTPServer`
- Frontiers: dynamic_handler_identity: next t9; dynamic_route_identity: next t9; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## txn-mixed

- ID: `trigger-57af46bb0c441aec237c9690`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/v3/tools/benchmark/cmd.mixedTxnFunc`
- Dispatcher: `go.etcd.io/etcd/v3/tools/benchmark/cmd.init#8`
- Registration: `tools/benchmark/cmd/txn_mixed.go:54` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## unresolved value

- ID: `trigger-58d93e473a195f1c54702961`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `unresolved value`
- Registration: `server/etcdserver/api/etcdhttp/health.go:61` via `net-http-servemux-handle`
- Server start: `server/embed/etcd.go:605`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.(*Etcd).serveClients` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.HandleHealth`
- Frontiers: dynamic_handler_identity: unresolved value; dynamic_route_identity: unresolved value

## HTTP server

- ID: `trigger-594b5e9bcb97d2242f5eb5bb`
- Status: `confirmed_server_start_call`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact server start can seed a partial operational trace; accept and dispatch order remain unresolved
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `unresolved value`
- Registration: `server/embed/etcd.go:605` via `net-http-server-serve`
- Server start: `server/embed/etcd.go:605`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.(*Etcd).servePeers`
- Frontiers: unresolved_dispatch_inventory: No supported route registration was correlated with this static server start call.

## snapshot restore

- ID: `trigger-5dde979320807e44cf48d6a4`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/etcdutl/v3/etcdutl.snapshotRestoreCommandFunc`
- Dispatcher: `go.etcd.io/etcd/etcdutl/v3/etcdutl.NewSnapshotCommand`
- Registration: `etcdutl/etcdutl/snapshot_command.go:53` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## benchmark

- ID: `trigger-5ff066d28d06eda387644bb3`
- Status: `partial_cobra_activation`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command activation can seed a partial path; child dispatch and downstream effects remain unresolved
- Executable: `tools/benchmark`; role `tooling`; availability `available`
- Handler: `Run/RunE descriptor initializer unresolved`
- Dispatcher: `no exact shallow registration or activation`
- Registration: unresolved via `cobra-command-activation`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## HTTP server

- ID: `trigger-60b0a08114ff39e9856099d5`
- Status: `confirmed_server_start_call`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact server start can seed a partial operational trace; accept and dispatch order remain unresolved
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unknown`
- Dispatcher: `unknown`
- Registration: `server/embed/serve.go:208` via `net-http-server-serve`
- Server start: `server/embed/serve.go:208`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved; unresolved_dispatch_inventory: No supported route registration was correlated with this static server start call.

## unresolved value

- ID: `trigger-62ba12e12df45256d0934bdf`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `unresolved value`
- Registration: `server/etcdserver/api/etcdhttp/peer.go:69` via `net-http-servemux-handle`
- Server start: `server/embed/etcd.go:605`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.(*Etcd).servePeers` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.NewPeerHandler` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.newPeerHandler`
- Frontiers: dynamic_handler_identity: unresolved value; dynamic_route_identity: unresolved value

## unresolved value

- ID: `trigger-63035bf618ba489146dfeb64`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `unresolved value`
- Registration: `server/etcdserver/api/etcdhttp/version.go:31` via `net-http-servemux-handlefunc`
- Server start: `server/embed/etcd.go:605`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.(*Etcd).serveClients` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.HandleVersion`
- Frontiers: dynamic_handler_identity: unresolved value; dynamic_route_identity: unresolved value

## etcd

- ID: `trigger-632d9eb1cb91ac230cce8c7a`
- Status: `partial_cobra_activation`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command activation can seed a partial path; child dispatch and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `Run/RunE descriptor initializer unresolved`
- Dispatcher: `no exact shallow registration or activation`
- Registration: unresolved via `cobra-command-activation`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## /proxy/metrics

- ID: `trigger-6459e3b6e01d50e068e0e40e`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `result of github.com/prometheus/client_golang/prometheus/promhttp.Handler`
- Dispatcher: `net/http.NewServeMux@server/etcdmain/grpc_proxy.go:564:29`
- Registration: `server/proxy/grpcproxy/metrics.go:105` via `net-http-servemux-handle`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.mustHTTPServer` → `go.etcd.io/etcd/server/v3/proxy/grpcproxy.HandleProxyMetrics`
- Frontiers: dynamic_handler_identity: result of github.com/prometheus/client_golang/prometheus/promhttp.Handler; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## rw-heatmaps

- ID: `trigger-65ee3964f408eb68d7232d80`
- Status: `partial_cobra_activation`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command activation can seed a partial path; child dispatch and downstream effects remain unresolved
- Executable: `tools/rw-heatmaps`; role `tooling`; availability `available`
- Handler: `go.etcd.io/etcd/tools/rw-heatmaps/v3/cmd.func_literal@tools/rw-heatmaps/cmd/root.go:48:9`
- Dispatcher: `no exact shallow registration or activation`
- Registration: unresolved via `cobra-command-activation`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## unresolved value

- ID: `trigger-686ae8f8c693dfb6f8b4fd58`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `unresolved value`
- Registration: `server/etcdserver/api/etcdhttp/debug.go:28` via `net-http-servemux-handlefunc`
- Server start: `server/embed/etcd.go:605`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.(*Etcd).serveClients` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.HandleDebug`
- Frontiers: dynamic_handler_identity: unresolved value; dynamic_route_identity: unresolved value

## /metrics

- ID: `trigger-6901df52e2127789d1bb3503`
- Status: `confirmed_through_repository_wrapper`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `go.etcd.io/etcd/server/v3/proxy/grpcproxy.HandleMetrics$1`
- Dispatcher: `net/http.NewServeMux@server/etcdmain/grpc_proxy.go:604:26`
- Registration: `server/proxy/grpcproxy/metrics.go:81` via `net-http-servemux-handlefunc`
- Wrapper chain: `go.etcd.io/etcd/server/v3/proxy/grpcproxy.HandleMetrics`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## unresolved value

- ID: `trigger-6a93649f1c506608500c2910`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `unresolved value`
- Registration: `server/etcdserver/api/etcdhttp/health.go:329` via `net-http-servemux-handle`
- Server start: `server/embed/etcd.go:605`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.(*Etcd).serveClients` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.HandleHealth` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.installLivezEndpoints` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.(*CheckRegistry).InstallHTTPEndpoints` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.(*CheckRegistry).installRootHTTPEndpoint`
- Frontiers: dynamic_handler_identity: unresolved value; dynamic_route_identity: unresolved value

## txn-put

- ID: `trigger-71344a8610cd787335867123`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/v3/tools/benchmark/cmd.txnPutFunc`
- Dispatcher: `go.etcd.io/etcd/v3/tools/benchmark/cmd.init#9`
- Registration: `tools/benchmark/cmd/txn_put.go:48` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## grpc-proxy start

- ID: `trigger-726ba369781e9139614428c4`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/server/v3/etcdmain.startGRPCProxy`
- Dispatcher: `go.etcd.io/etcd/server/v3/etcdmain.newGRPCProxyCommand`
- Registration: `server/etcdmain/grpc_proxy.go:127` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## main

- ID: `trigger-7298f88633b8a551e066c428`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a partial trace; downstream runtime handoff remains unresolved
- Executable: `tools/testgrid-analysis`; role `tooling`; availability `available`
- Handler: `go.etcd.io/etcd/tools/testgrid-analysis/v3.main`
- Dispatcher: `process entry`
- Registration: `tools/testgrid-analysis/main.go:19` via `gofacts-go-main`

## HTTP server

- ID: `trigger-799ba2eeceda6eb19459ebbc`
- Status: `confirmed_server_start_call`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact server start can seed a partial operational trace; accept and dispatch order remain unresolved
- Executable: `tools/etcd-dump-metrics`; role `tooling`; availability `available`
- Handler: `net/http.NewServeMux@server/etcdserver/api/etcdhttp/peer.go:62:25`
- Dispatcher: `net/http.NewServeMux@server/etcdserver/api/etcdhttp/peer.go:62:25`
- Registration: `server/embed/etcd.go:605` via `net-http-server-serve`
- Server start: `server/embed/etcd.go:605`
- Wrapper chain: `go.etcd.io/etcd/v3/tools/etcd-dump-metrics.main$4` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.(*Etcd).servePeers`
- Frontiers: unresolved_dispatch_inventory: No supported route registration was correlated with this static server start call.

## unresolved value

- ID: `trigger-7c5128e0d62390d7c2740207`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `unresolved value`
- Registration: `server/etcdserver/api/etcdhttp/peer.go:70` via `net-http-servemux-handle`
- Server start: `server/embed/etcd.go:605`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.(*Etcd).servePeers` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.NewPeerHandler` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.newPeerHandler`
- Frontiers: dynamic_handler_identity: unresolved value; dynamic_route_identity: unresolved value

## etcdutl

- ID: `trigger-7f9c365ab1375a6df13851c4`
- Status: `partial_cobra_activation`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command activation can seed a partial path; child dispatch and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `Run/RunE descriptor initializer unresolved`
- Dispatcher: `no exact shallow registration or activation`
- Registration: unresolved via `cobra-command-activation`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## go.etcd.io/etcd/server/v3/embed.setupLogRotation$1

- ID: `trigger-7fb59921e032150a666d4bce`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `tools/etcd-dump-metrics`; role `tooling`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `server/embed/config_logging.go:283` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/v3/tools/etcd-dump-metrics.main$4` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.(*Config).Validate` → `go.etcd.io/etcd/server/v3/embed.(*Config).setupLogging` → `go.etcd.io/etcd/server/v3/embed.setupLogRotation`
- Frontiers: dynamic_handler_identity: unknown handler

## go.etcd.io/etcd/tests/v3/robustness/traffic.RunKeyValueLoop$1

- ID: `trigger-7fcca430eecf635ce037fb66`
- Status: `confirmed_worker_registration`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `tests/antithesis/test-template/robustness/traffic`; role `test_or_helper`; availability `available`
- Handler: `go.etcd.io/etcd/tests/v3/robustness/traffic.RunKeyValueLoop$1`
- Dispatcher: `*golang.org/x/sync/errgroup.Group@tests/robustness/traffic/kubernetes.go:95:2`
- Registration: `tests/robustness/traffic/kubernetes.go:97` via `x-sync-errgroup-go`
- Wrapper chain: `go.etcd.io/etcd/tests/v3/robustness/traffic.(kubernetesTraffic).RunKeyValueLoop`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## next t1

- ID: `trigger-7ff0a67f7d96c207b5485591`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `next t1`
- Dispatcher: `typed registration receiver`
- Registration: `server/embed/serve.go:543` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.configureClientListeners` → `go.etcd.io/etcd/server/v3/embed.(*serveCtx).registerPprof`
- Frontiers: dynamic_handler_identity: next t1; dynamic_route_identity: next t1

## watch-latency

- ID: `trigger-83506b134a286a4bda0f62fc`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/v3/tools/benchmark/cmd.watchLatencyFunc`
- Dispatcher: `go.etcd.io/etcd/v3/tools/benchmark/cmd.init#12`
- Registration: `tools/benchmark/cmd/watch_latency.go:52` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## mvcc

- ID: `trigger-838a19adc753982568836346`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `Run/RunE descriptor initializer unresolved`
- Dispatcher: `go.etcd.io/etcd/v3/tools/benchmark/cmd.init#3`
- Registration: `tools/benchmark/cmd/mvcc.go:55` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## unresolved value

- ID: `trigger-84341286e6e7831c797a5c4f`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `server/storage/mvcc/kvstore.go:201` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/etcdserver.NewServer` → `go.etcd.io/etcd/server/v3/storage/mvcc.New` → `go.etcd.io/etcd/server/v3/storage/mvcc.newWatchableStore` → `go.etcd.io/etcd/server/v3/storage/mvcc.NewStore` → `go.etcd.io/etcd/server/v3/storage/mvcc.(*store).restore` → `go.etcd.io/etcd/server/v3/storage/mvcc.(*store).compactLockfree` → `go.etcd.io/etcd/server/v3/storage/mvcc.(*store).updateCompactRev`
- Frontiers: dynamic_handler_identity: unknown handler; dynamic_route_identity: unresolved value

## HTTP server

- ID: `trigger-88e9a990c0934600c5b115cf`
- Status: `confirmed_server_start_call`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact server start can seed a partial operational trace; accept and dispatch order remain unresolved
- Executable: `contrib/raftexample`; role `test_or_helper`; availability `available`
- Handler: `result of go.etcd.io/etcd/server/v3/etcdserver/api/rafthttp.(*Transport).Handler`
- Dispatcher: `result of go.etcd.io/etcd/server/v3/etcdserver/api/rafthttp.(*Transport).Handler`
- Registration: `contrib/raftexample/raft.go:510` via `net-http-server-serve`
- Server start: `contrib/raftexample/raft.go:510`
- Wrapper chain: `go.etcd.io/etcd/v3/contrib/raftexample.newRaftNode` → `go.etcd.io/etcd/v3/contrib/raftexample.(*raftNode).startRaft` → `go.etcd.io/etcd/v3/contrib/raftexample.(*raftNode).serveRaft`
- Frontiers: unresolved_dispatch_inventory: No supported route registration was correlated with this static server start call.

## grpc-proxy

- ID: `trigger-8959d777c1537fe9cbd8c517`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `Run/RunE descriptor initializer unresolved`
- Dispatcher: `go.etcd.io/etcd/server/v3/etcdmain.init#2`
- Registration: `server/etcdmain/grpc_proxy.go:118` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## go.etcd.io/etcd/tests/v3/robustness/traffic.RunKeyValueLoop$2

- ID: `trigger-8c54fe13371e651e5f283c96`
- Status: `confirmed_worker_registration`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `tests/antithesis/test-template/robustness/traffic`; role `test_or_helper`; availability `available`
- Handler: `go.etcd.io/etcd/tests/v3/robustness/traffic.RunKeyValueLoop$2`
- Dispatcher: `*golang.org/x/sync/errgroup.Group@tests/robustness/traffic/kubernetes.go:95:2`
- Registration: `tests/robustness/traffic/kubernetes.go:112` via `x-sync-errgroup-go`
- Wrapper chain: `go.etcd.io/etcd/tests/v3/robustness/traffic.(kubernetesTraffic).RunKeyValueLoop`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## snapshot

- ID: `trigger-8c8138692b1f8313ff526b50`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `Run/RunE descriptor initializer unresolved`
- Dispatcher: `go.etcd.io/etcd/etcdutl/v3.init#1`
- Registration: `etcdutl/ctl.go:44` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## HTTP server

- ID: `trigger-8d40cae182602b0db212b898`
- Status: `confirmed_server_start_call`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact server start can seed a partial operational trace; accept and dispatch order remain unresolved
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unknown`
- Dispatcher: `unknown`
- Registration: `server/etcdmain/grpc_proxy.go:279` via `net-http-server-serve`
- Server start: `server/etcdmain/grpc_proxy.go:279`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved; unresolved_dispatch_inventory: No supported route registration was correlated with this static server start call.

## /

- ID: `trigger-90a15b37f90ebe3a10d881b0`
- Status: `confirmed_direct_registration`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `trace_ready`
- Trace readiness reason: exact route identity, registration, handler, and bounded static reachability can seed a request trace
- Executable: `contrib/lock/storage`; role `test_or_helper`; availability `available`
- Handler: `go.etcd.io/etcd/v3/contrib/lock/storage.handler`
- Dispatcher: `net/http.DefaultServeMux`
- Registration: `contrib/lock/storage/storage.go:105` via `net-http-default-handlefunc`
- Server start: `contrib/lock/storage/storage.go:106`

## range

- ID: `trigger-98d5b50ac600da82baf83091`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/v3/tools/benchmark/cmd.rangeFunc`
- Dispatcher: `go.etcd.io/etcd/v3/tools/benchmark/cmd.init#5`
- Registration: `tools/benchmark/cmd/range.go:59` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## go.etcd.io/etcd/server/v3/etcdserver/api/rafthttp.RaftPrefix

- ID: `trigger-9a02b55b422eb10300c1bce6`
- Status: `confirmed_through_repository_wrapper`; certainty `static`; resolution `ambiguous`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `contrib/raftexample`; role `test_or_helper`; availability `available`
- Handler: `*go.etcd.io/etcd/server/v3/etcdserver/api/rafthttp.pipelineHandler@server/etcdserver/api/rafthttp/http.go:82:23`
- Dispatcher: `net/http.NewServeMux@server/etcdserver/api/rafthttp/transport.go:161:25`
- Registration: `server/etcdserver/api/rafthttp/transport.go:162` via `net-http-servemux-handle`
- Wrapper chain: `go.etcd.io/etcd/v3/contrib/raftexample.newRaftNode` → `go.etcd.io/etcd/v3/contrib/raftexample.(*raftNode).startRaft` → `go.etcd.io/etcd/v3/contrib/raftexample.(*raftNode).serveRaft` → `go.etcd.io/etcd/server/v3/etcdserver/api/rafthttp.(*Transport).Handler`

## main

- ID: `trigger-9f20ba3d387751ee59bd5e1e`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a partial trace; downstream runtime handoff remains unresolved
- Executable: `contrib/lock/client`; role `test_or_helper`; availability `available`
- Handler: `go.etcd.io/etcd/v3/contrib/lock/client.main`
- Dispatcher: `process entry`
- Registration: `contrib/lock/client/client.go:87` via `gofacts-go-main`

## unresolved value

- ID: `trigger-9fd798919f87c2e395bac3bf`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `unresolved value`
- Registration: `server/etcdserver/api/etcdhttp/peer.go:67` via `net-http-servemux-handle`
- Server start: `server/embed/etcd.go:605`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.(*Etcd).servePeers` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.NewPeerHandler` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.newPeerHandler`
- Frontiers: dynamic_handler_identity: unresolved value; dynamic_route_identity: unresolved value

## go.etcd.io/etcd/tests/v3/antithesis/test-template/robustness/traffic.runTraffic$1

- ID: `trigger-a6e3db947a560b2d2d2b1efa`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `tests/antithesis/test-template/robustness/traffic`; role `test_or_helper`; availability `available`
- Handler: `go.etcd.io/etcd/tests/v3/antithesis/test-template/robustness/traffic.runTraffic$1`
- Dispatcher: `*golang.org/x/sync/errgroup.Group@tests/antithesis/test-template/robustness/traffic/main.go:103:2`
- Registration: `tests/antithesis/test-template/robustness/traffic/main.go:105` via `x-sync-errgroup-go`
- Wrapper chain: `go.etcd.io/etcd/tests/v3/antithesis/test-template/robustness/traffic.runTraffic`

## main

- ID: `trigger-aafd7eb5ae00460cde77f1cf`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a partial trace; downstream runtime handoff remains unresolved
- Executable: `contrib/raftexample`; role `test_or_helper`; availability `available`
- Handler: `go.etcd.io/etcd/v3/contrib/raftexample.main`
- Dispatcher: `process entry`
- Registration: `contrib/raftexample/main.go:24` via `gofacts-go-main`

## proto-annotation

- ID: `trigger-ad73a1db032f747e675fd0f6`
- Status: `partial_cobra_activation`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command activation can seed a partial path; child dispatch and downstream effects remain unresolved
- Executable: `tools/proto-annotations`; role `tooling`; availability `available`
- Handler: `go.etcd.io/etcd/v3/tools/proto-annotations/cmd.func_literal@tools/proto-annotations/cmd/root.go:52:9`
- Dispatcher: `no exact shallow registration or activation`
- Registration: unresolved via `cobra-command-activation`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## go.etcd.io/etcd/server/v3/storage/mvcc.compact$1

- ID: `trigger-af05c0d3fb5d8301afb628e6`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `tools/etcd-dump-metrics`; role `tooling`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `server/storage/mvcc/kvstore.go:236` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/v3/tools/etcd-dump-metrics.main$4` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/etcdserver.NewServer` → `go.etcd.io/etcd/server/v3/storage/mvcc.New` → `go.etcd.io/etcd/server/v3/storage/mvcc.newWatchableStore` → `go.etcd.io/etcd/server/v3/storage/mvcc.NewStore` → `go.etcd.io/etcd/server/v3/storage/mvcc.(*store).restore` → `go.etcd.io/etcd/server/v3/storage/mvcc.(*store).compactLockfree` → `go.etcd.io/etcd/server/v3/storage/mvcc.(*store).compact`
- Frontiers: dynamic_handler_identity: unknown handler

## /debug/events

- ID: `trigger-afdcae27e6d0cf09abaa7a95`
- Status: `confirmed_typed_registration`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `trace_ready`
- Trace readiness reason: exact route identity, registration, handler, and bounded static reachability can seed a request trace
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `go.etcd.io/etcd/server/v3/embed.registerTrace$2`
- Dispatcher: `typed registration receiver`
- Registration: `server/embed/serve.go:551` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.configureClientListeners` → `go.etcd.io/etcd/server/v3/embed.(*serveCtx).registerTrace`

## /

- ID: `trigger-b1147cd75706288f10676280`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `**net/http.ServeMux@server/embed/etcd.go:770:2 | go.etcd.io/etcd/server/v3/embed.grpcHandlerFunc$1 | go.etcd.io/etcd/server/v3/embed.grpcHandlerFunc$2`
- Dispatcher: `net/http.NewServeMux@server/embed/serve.go:390:29`
- Registration: `server/embed/serve.go:413` via `net-http-servemux-handle`
- Wrapper chain: `go.etcd.io/etcd/server/v3/embed.(*serveCtx).serve` → `go.etcd.io/etcd/server/v3/embed.(*serveCtx).createMux`
- Frontiers: dynamic_handler_identity: **net/http.ServeMux@server/embed/etcd.go:770:2 | go.etcd.io/etcd/server/v3/embed.grpcHandlerFunc$1 | go.etcd.io/etcd/server/v3/embed.grpcHandlerFunc$2; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## unresolved route alternative

- ID: `trigger-b67f17aabf72b9ba5ad32ee4`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.newHealthHandler$1`
- Dispatcher: `parameter mux`
- Registration: `server/etcdserver/api/etcdhttp/health.go:329` via `net-http-servemux-handle`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.(*CheckRegistry).InstallHTTPEndpoints` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.(*CheckRegistry).installRootHTTPEndpoint`
- Frontiers: dynamic_route_identity: unresolved route alternative; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## unresolved value

- ID: `trigger-b87d100fe3f2ecbca9e20121`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `typed registration receiver`
- Registration: `server/embed/serve.go:549` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.configureClientListeners` → `go.etcd.io/etcd/server/v3/embed.(*serveCtx).registerTrace`
- Frontiers: dynamic_handler_identity: unresolved value; dynamic_route_identity: unresolved value

## watch

- ID: `trigger-b9476c66ef8ba5d4f2109f8a`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/v3/tools/benchmark/cmd.watchFunc`
- Dispatcher: `go.etcd.io/etcd/v3/tools/benchmark/cmd.init#10`
- Registration: `tools/benchmark/cmd/watch.go:78` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## unresolved value

- ID: `trigger-bc64f532c5f14cf52508ecde`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `unresolved value`
- Registration: `server/etcdserver/api/etcdhttp/peer.go:73` via `net-http-servemux-handle`
- Server start: `server/embed/etcd.go:605`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.(*Etcd).servePeers` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.NewPeerHandler` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.newPeerHandler`
- Frontiers: dynamic_handler_identity: unresolved value; dynamic_route_identity: unresolved value

## main

- ID: `trigger-bcd368d0cde8d7b18edb9f85`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a partial trace; downstream runtime handoff remains unresolved
- Executable: `tests/antithesis/test-template/robustness/finally`; role `test_or_helper`; availability `available`
- Handler: `go.etcd.io/etcd/tests/v3/antithesis/test-template/robustness/finally.main`
- Dispatcher: `process entry`
- Registration: `tests/antithesis/test-template/robustness/finally/main.go:38` via `gofacts-go-main`

## hash

- ID: `trigger-bd9daf521831234ea03cf9e8`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/v3/tools/etcd-dump-db.getHashCommandFunc`
- Dispatcher: `go.etcd.io/etcd/v3/tools/etcd-dump-db.init#1`
- Registration: `tools/etcd-dump-db/main.go:72` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## /debug/requests

- ID: `trigger-bf3dee6790cf381ebdfed9d8`
- Status: `confirmed_typed_registration`; certainty `static`; resolution `ambiguous`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `tools/etcd-dump-metrics`; role `tooling`; availability `available`
- Handler: `go.etcd.io/etcd/server/v3/embed.registerTrace$1`
- Dispatcher: `typed registration receiver`
- Registration: `server/embed/serve.go:549` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/v3/tools/etcd-dump-metrics.main$4` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.configureClientListeners` → `go.etcd.io/etcd/server/v3/embed.(*serveCtx).registerTrace`

## /health

- ID: `trigger-bf639571d74959e293169daa`
- Status: `confirmed_through_repository_wrapper`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.NewHealthHandler$1`
- Dispatcher: `net/http.NewServeMux@server/etcdmain/grpc_proxy.go:604:26`
- Registration: `server/proxy/grpcproxy/health.go:36` via `net-http-servemux-handle`
- Wrapper chain: `go.etcd.io/etcd/server/v3/proxy/grpcproxy.HandleHealth`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## unresolved value

- ID: `trigger-c487a8acbf758d422a1052f5`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `server/embed/config_logging.go:283` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.(*Config).Validate` → `go.etcd.io/etcd/server/v3/embed.(*Config).setupLogging` → `go.etcd.io/etcd/server/v3/embed.setupLogRotation`
- Frontiers: dynamic_handler_identity: unknown handler; dynamic_route_identity: unresolved value

## main

- ID: `trigger-c706e1b6637238aa24db11bd`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a partial trace; downstream runtime handoff remains unresolved
- Executable: `tests/antithesis/test-template/robustness/traffic`; role `test_or_helper`; availability `available`
- Handler: `go.etcd.io/etcd/tests/v3/antithesis/test-template/robustness/traffic.main`
- Dispatcher: `process entry`
- Registration: `tests/antithesis/test-template/robustness/traffic/main.go:65` via `gofacts-go-main`

## /

- ID: `trigger-cab76b6c015efa2be24952e2`
- Status: `confirmed_through_repository_wrapper`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `**net/http.ServeMux@server/embed/etcd.go:770:2`
- Dispatcher: `net/http.NewServeMux@server/embed/serve.go:390:29`
- Registration: `server/embed/serve.go:413` via `net-http-servemux-handle`
- Wrapper chain: `go.etcd.io/etcd/server/v3/embed.(*serveCtx).serve` → `go.etcd.io/etcd/server/v3/embed.(*serveCtx).createMux`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## /health

- ID: `trigger-cb6e2f582ffd8a7062b74ea6`
- Status: `confirmed_through_repository_wrapper`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.NewHealthHandler$1`
- Dispatcher: `net/http.NewServeMux@server/etcdmain/grpc_proxy.go:564:29`
- Registration: `server/proxy/grpcproxy/health.go:36` via `net-http-servemux-handle`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.mustHTTPServer` → `go.etcd.io/etcd/server/v3/proxy/grpcproxy.HandleHealth`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## HTTP server

- ID: `trigger-ce0b10b0a0cd70c6126e6c57`
- Status: `confirmed_server_start_call`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact server start can seed a partial operational trace; accept and dispatch order remain unresolved
- Executable: `contrib/lock/storage`; role `test_or_helper`; availability `available`
- Handler: `net/http.DefaultServeMux`
- Dispatcher: `net/http.DefaultServeMux`
- Registration: `contrib/lock/storage/storage.go:106` via `net-http-listen-and-serve`
- Server start: `contrib/lock/storage/storage.go:106`

## unresolved value

- ID: `trigger-ce888d081527608e531ead2e`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `unresolved value`
- Registration: `server/etcdserver/api/etcdhttp/peer.go:65` via `net-http-servemux-handle`
- Server start: `server/embed/etcd.go:605`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.(*Etcd).servePeers` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.NewPeerHandler` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.newPeerHandler`
- Frontiers: dynamic_handler_identity: unresolved value; dynamic_route_identity: unresolved value

## go.etcd.io/etcd/tests/v3/robustness/client.CollectClusterWatchEvents$1

- ID: `trigger-cea7ce8d55c0b26864a84e38`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `tests/antithesis/test-template/robustness/traffic`; role `test_or_helper`; availability `available`
- Handler: `go.etcd.io/etcd/tests/v3/robustness/client.CollectClusterWatchEvents$1`
- Dispatcher: `*golang.org/x/sync/errgroup.Group@tests/robustness/client/watch.go:35:6`
- Registration: `tests/robustness/client/watch.go:40` via `x-sync-errgroup-go`
- Wrapper chain: `go.etcd.io/etcd/tests/v3/robustness/client.CollectClusterWatchEvents`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## mvcc put

- ID: `trigger-d07bb1299709f98b56c7492b`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/v3/tools/benchmark/cmd.mvccPutFunc`
- Dispatcher: `go.etcd.io/etcd/v3/tools/benchmark/cmd.init#2`
- Registration: `tools/benchmark/cmd/mvcc-put.go:48` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## unresolved value

- ID: `trigger-d2a96f51b2c5beaee40be082`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `server/storage/mvcc/kvstore.go:236` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/etcdserver.NewServer` → `go.etcd.io/etcd/server/v3/storage/mvcc.New` → `go.etcd.io/etcd/server/v3/storage/mvcc.newWatchableStore` → `go.etcd.io/etcd/server/v3/storage/mvcc.NewStore` → `go.etcd.io/etcd/server/v3/storage/mvcc.(*store).restore` → `go.etcd.io/etcd/server/v3/storage/mvcc.(*store).compactLockfree` → `go.etcd.io/etcd/server/v3/storage/mvcc.(*store).compact`
- Frontiers: dynamic_handler_identity: unknown handler; dynamic_route_identity: unresolved value

## main

- ID: `trigger-d2ccfa2911f965e5250edc91`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a partial trace; downstream runtime handoff remains unresolved
- Executable: `etcdutl`; role `tooling`; availability `available`
- Handler: `go.etcd.io/etcd/etcdutl/v3.main`
- Dispatcher: `process entry`
- Registration: `etcdutl/main.go:22` via `gofacts-go-main`

## version

- ID: `trigger-d2f91028dd70b4b1bda052a3`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/etcdutl/v3/etcdutl.versionCommandFunc`
- Dispatcher: `go.etcd.io/etcd/etcdutl/v3.init#1`
- Registration: `etcdutl/ctl.go:44` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## etcdctl

- ID: `trigger-d3aab8f6ede195021be1382b`
- Status: `partial_cobra_activation`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command activation can seed a partial path; child dispatch and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `Run/RunE descriptor initializer unresolved`
- Dispatcher: `no exact shallow registration or activation`
- Registration: unresolved via `cobra-command-activation`
- Frontiers: cobra_binding_unresolved: typed AddCommand relation is not a direct, unconditional single-definition binding; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## unresolved value

- ID: `trigger-d56313579ac7df611ec2d574`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `typed registration receiver`
- Registration: `server/embed/serve.go:551` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.configureClientListeners` → `go.etcd.io/etcd/server/v3/embed.(*serveCtx).registerTrace`
- Frontiers: dynamic_handler_identity: unresolved value; dynamic_route_identity: unresolved value

## defrag

- ID: `trigger-d5ed54e056f88fdef581f8f0`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/etcdutl/v3/etcdutl.defragCommandFunc`
- Dispatcher: `go.etcd.io/etcd/etcdutl/v3.init#1`
- Registration: `etcdutl/ctl.go:44` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## list-bucket

- ID: `trigger-de8d94778b9650c8ac542a56`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/v3/tools/etcd-dump-db.listBucketCommandFunc`
- Dispatcher: `go.etcd.io/etcd/v3/tools/etcd-dump-db.init#1`
- Registration: `tools/etcd-dump-db/main.go:69` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## next t1

- ID: `trigger-e0fdd2ad6fd7a34c80033f8f`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `tools/etcd-dump-metrics`; role `tooling`; availability `available`
- Handler: `next t1`
- Dispatcher: `typed registration receiver`
- Registration: `server/embed/serve.go:543` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/v3/tools/etcd-dump-metrics.main$4` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.configureClientListeners` → `go.etcd.io/etcd/server/v3/embed.(*serveCtx).registerPprof`
- Frontiers: dynamic_handler_identity: next t1; dynamic_route_identity: next t1

## HTTP server

- ID: `trigger-e2d1c8c6b7718bcfb7ee530b`
- Status: `confirmed_server_start_call`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact server start can seed a partial operational trace; accept and dispatch order remain unresolved
- Executable: `contrib/raftexample`; role `test_or_helper`; availability `available`
- Handler: `*go.etcd.io/etcd/v3/contrib/raftexample.httpKVAPI@contrib/raftexample/httpapi.go:107:22`
- Dispatcher: `*go.etcd.io/etcd/v3/contrib/raftexample.httpKVAPI@contrib/raftexample/httpapi.go:107:22`
- Registration: `contrib/raftexample/httpapi.go:113` via `net-http-server-listen-and-serve`
- Server start: `contrib/raftexample/httpapi.go:113`
- Wrapper chain: `go.etcd.io/etcd/v3/contrib/raftexample.serveHTTPKVAPI` → `go.etcd.io/etcd/v3/contrib/raftexample.serveHTTPKVAPI$1`
- Frontiers: unresolved_dispatch_inventory: No supported route registration was correlated with this static server start call.

## main

- ID: `trigger-e4bce47678b3d5d3d72d7a7c`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a partial trace; downstream runtime handoff remains unresolved
- Executable: `tools/rw-heatmaps`; role `tooling`; availability `available`
- Handler: `go.etcd.io/etcd/tools/rw-heatmaps/v3.main`
- Dispatcher: `process entry`
- Registration: `tools/rw-heatmaps/main.go:24` via `gofacts-go-main`

## unresolved value

- ID: `trigger-e4e93d7c0510941926e79101`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `unresolved value`
- Registration: `server/etcdserver/api/etcdhttp/peer.go:66` via `net-http-servemux-handle`
- Server start: `server/embed/etcd.go:605`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.(*Etcd).servePeers` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.NewPeerHandler` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.newPeerHandler`
- Frontiers: dynamic_handler_identity: unresolved value; dynamic_route_identity: unresolved value

## main

- ID: `trigger-e8b76c45ff12e2ec29a80ff4`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a partial trace; downstream runtime handoff remains unresolved
- Executable: `tools/benchmark`; role `tooling`; availability `available`
- Handler: `go.etcd.io/etcd/v3/tools/benchmark.main`
- Dispatcher: `process entry`
- Registration: `tools/benchmark/main.go:24` via `gofacts-go-main`

## main

- ID: `trigger-ec41e773bf210da6444556e8`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a partial trace; downstream runtime handoff remains unresolved
- Executable: `tools/check-grpc-experimental`; role `tooling`; availability `available`
- Handler: `go.etcd.io/etcd/v3/tools/check-grpc-experimental.main`
- Dispatcher: `process entry`
- Registration: `tools/check-grpc-experimental/main.go:43` via `gofacts-go-main`

## go.etcd.io/etcd/server/v3/etcdserver/api/rafthttp.RaftSnapshotPrefix

- ID: `trigger-ed4b8a113d6c5c7a539c6b56`
- Status: `confirmed_through_repository_wrapper`; certainty `static`; resolution `ambiguous`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `contrib/raftexample`; role `test_or_helper`; availability `available`
- Handler: `*go.etcd.io/etcd/server/v3/etcdserver/api/rafthttp.snapshotHandler@server/etcdserver/api/rafthttp/http.go:175:23`
- Dispatcher: `net/http.NewServeMux@server/etcdserver/api/rafthttp/transport.go:161:25`
- Registration: `server/etcdserver/api/rafthttp/transport.go:164` via `net-http-servemux-handle`
- Wrapper chain: `go.etcd.io/etcd/v3/contrib/raftexample.newRaftNode` → `go.etcd.io/etcd/v3/contrib/raftexample.(*raftNode).startRaft` → `go.etcd.io/etcd/v3/contrib/raftexample.(*raftNode).serveRaft` → `go.etcd.io/etcd/server/v3/etcdserver/api/rafthttp.(*Transport).Handler`

## main

- ID: `trigger-ed73d9ab91c76f3d0f7efdd8`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a partial trace; downstream runtime handoff remains unresolved
- Executable: `tools/etcd-dump-logs`; role `tooling`; availability `available`
- Handler: `go.etcd.io/etcd/v3/tools/etcd-dump-logs.main`
- Dispatcher: `process entry`
- Registration: `tools/etcd-dump-logs/main.go:52` via `gofacts-go-main`

## /debug/requests

- ID: `trigger-efdccd3222b648a783bdc299`
- Status: `confirmed_typed_registration`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `trace_ready`
- Trace readiness reason: exact route identity, registration, handler, and bounded static reachability can seed a request trace
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `go.etcd.io/etcd/server/v3/embed.registerTrace$1`
- Dispatcher: `typed registration receiver`
- Registration: `server/embed/serve.go:549` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.configureClientListeners` → `go.etcd.io/etcd/server/v3/embed.(*serveCtx).registerTrace`

## /v3/

- ID: `trigger-f2d938f63eb829c5f39cb90b`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `result of github.com/tmc/grpc-websocket-proxy/wsproxy.WebsocketProxy`
- Dispatcher: `net/http.NewServeMux@server/embed/serve.go:390:29`
- Registration: `server/embed/serve.go:396` via `net-http-servemux-handle`
- Wrapper chain: `go.etcd.io/etcd/server/v3/embed.(*serveCtx).serve` → `go.etcd.io/etcd/server/v3/embed.(*serveCtx).createMux`
- Frontiers: dynamic_handler_identity: result of github.com/tmc/grpc-websocket-proxy/wsproxy.WebsocketProxy; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## /debug/events

- ID: `trigger-f396fcf5d0ec1071ebbebc3d`
- Status: `confirmed_typed_registration`; certainty `static`; resolution `ambiguous`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `tools/etcd-dump-metrics`; role `tooling`; availability `available`
- Handler: `go.etcd.io/etcd/server/v3/embed.registerTrace$2`
- Dispatcher: `typed registration receiver`
- Registration: `server/embed/serve.go:551` via `typed_registration_detector`
- Wrapper chain: `go.etcd.io/etcd/v3/tools/etcd-dump-metrics.main$4` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.configureClientListeners` → `go.etcd.io/etcd/server/v3/embed.(*serveCtx).registerTrace`

## go.etcd.io/etcd/tests/v3/framework/e2e.DowngradeUpgradeMembersByID$1

- ID: `trigger-f3e80abcf73dbd5bfa9b2c67`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `tests/antithesis/test-template/robustness/finally`; role `test_or_helper`; availability `available`
- Handler: `go.etcd.io/etcd/tests/v3/framework/e2e.DowngradeUpgradeMembersByID$1`
- Dispatcher: `*golang.org/x/sync/errgroup.Group@tests/framework/e2e/downgrade.go:155:10`
- Registration: `tests/framework/e2e/downgrade.go:175` via `x-sync-errgroup-go`
- Wrapper chain: `go.etcd.io/etcd/tests/v3/framework/e2e.DowngradeUpgradeMembersByID`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## iterate-bucket

- ID: `trigger-f450cf03f344cf5227b9e5c3`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/v3/tools/etcd-dump-db.iterateBucketCommandFunc`
- Dispatcher: `go.etcd.io/etcd/v3/tools/etcd-dump-db.init#1`
- Registration: `tools/etcd-dump-db/main.go:70` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## go.etcd.io/etcd/tests/v3/robustness/client.CollectClusterWatchEvents$2

- ID: `trigger-f535fc4741e0164edeaea0b9`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `tests/antithesis/test-template/robustness/traffic`; role `test_or_helper`; availability `available`
- Handler: `go.etcd.io/etcd/tests/v3/robustness/client.CollectClusterWatchEvents$2`
- Dispatcher: `*golang.org/x/sync/errgroup.Group@tests/robustness/client/watch.go:35:6`
- Registration: `tests/robustness/client/watch.go:49` via `x-sync-errgroup-go`
- Wrapper chain: `go.etcd.io/etcd/tests/v3/robustness/client.CollectClusterWatchEvents`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## completion

- ID: `trigger-f5f3d75444cbaa8809e0e74e`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/etcdutl/v3/etcdutl.func_literal@etcdutl/etcdutl/completion_commmand.go:69:8`
- Dispatcher: `go.etcd.io/etcd/etcdutl/v3.init#1`
- Registration: `etcdutl/ctl.go:44` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## flaky

- ID: `trigger-f7dda38bf3be305c20dfe9dd`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `go.etcd.io/etcd/tools/testgrid-analysis/v3/cmd.flakyFunc`
- Dispatcher: `go.etcd.io/etcd/tools/testgrid-analysis/v3/cmd.init#1`
- Registration: `tools/testgrid-analysis/cmd/flaky.go:44` via `cobra-command-binding`
- Frontiers: shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## unresolved value

- ID: `trigger-fa85090046d66e3b9e7c2d81`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `unresolved value`
- Dispatcher: `unresolved value`
- Registration: `server/etcdserver/api/etcdhttp/peer.go:64` via `net-http-servemux-handle`
- Server start: `server/embed/etcd.go:605`
- Wrapper chain: `go.etcd.io/etcd/server/v3/etcdmain.Main` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcdOrProxyV2` → `go.etcd.io/etcd/server/v3/etcdmain.startEtcd` → `go.etcd.io/etcd/server/v3/embed.StartEtcd` → `go.etcd.io/etcd/server/v3/embed.(*Etcd).servePeers` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.NewPeerHandler` → `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.newPeerHandler`
- Frontiers: dynamic_handler_identity: unresolved value; dynamic_route_identity: unresolved value

## next t3

- ID: `trigger-ffdcfba6ac91530dccbc6912`
- Status: `dynamic_unknown`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `server`; role `primary_application`; availability `available`
- Handler: `next t3`
- Dispatcher: `net/http.NewServeMux@server/embed/serve.go:390:29`
- Registration: `server/embed/serve.go:392` via `net-http-servemux-handle`
- Wrapper chain: `go.etcd.io/etcd/server/v3/embed.(*serveCtx).serve` → `go.etcd.io/etcd/server/v3/embed.(*serveCtx).createMux`
- Frontiers: dynamic_handler_identity: next t3; dynamic_route_identity: next t3; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## Loop signals

- `registration_loop` in `go.etcd.io/etcd/server/v3/embed.(*serveCtx).createMux` at `server/embed/serve.go:392`: configured registration sink occurs inside a control-flow loop; registration cardinality may be dynamic
- `registration_loop` in `go.etcd.io/etcd/server/v3/etcdmain.mustHTTPServer` at `server/etcdmain/grpc_proxy.go:572`: configured registration sink occurs inside a control-flow loop; registration cardinality may be dynamic
- `registration_loop` in `go.etcd.io/etcd/server/v3/etcdserver/api/etcdhttp.(*CheckRegistry).InstallHTTPEndpoints` at `server/etcdserver/api/etcdhttp/health.go:292`: configured registration sink occurs inside a control-flow loop; registration cardinality may be dynamic
- `control_flow_loop` in `go.etcd.io/etcd/tests/v3/robustness/client.CollectClusterWatchEvents$2` at `tests/robustness/client/watch.go:49`: bounded SSA control-flow cycle
- `select_event_loop` in `go.etcd.io/etcd/tests/v3/robustness/traffic.RunKeyValueLoop$1` at `tests/robustness/traffic/kubernetes.go:100`: control-flow loop contains a select; cancellation and runtime branch choice remain unproven
- `select_event_loop` in `go.etcd.io/etcd/tests/v3/robustness/traffic.RunKeyValueLoop$2` at `tests/robustness/traffic/kubernetes.go:113`: control-flow loop contains a select; cancellation and runtime branch choice remain unproven

Budgets reached: `architecture_anchors`, `depth`, `value_depth`, `value_description`, `value_evaluation`, `value_evaluation_cycle`.
