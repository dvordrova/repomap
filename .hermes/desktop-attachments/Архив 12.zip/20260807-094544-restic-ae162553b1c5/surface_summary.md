# Runtime surfaces

Repository: `/Users/dvordrova/git/restic`

Scenario: `go:darwin/amd64:tags=`

Discovered 103 static surface record(s): 48 direct, 55 wrapper-derived.

Cobra inventory: 37 descriptor(s), 35 exact binding(s), 1 exact activation(s), 1 partial relation(s), 0 duplicate relation(s), 37 retained record(s), 0 dropped record(s).

This is not a runtime trace. exact build-selected process entries, typed Cobra commands, runtime registrations and starts found through safe typed package closures, bounded wrapper propagation, and the generic typed registration detector (path string + handler) under the recorded build scenario, subject to listed diagnostics and frontiers.

## Discovery phases

- `package_load`: 1230 ms (62/62) — loading build-selected packages and dependency type information
- `ssa_build`: 156 ms (62/62) — building SSA for repository packages with dependency type information
- `call_graph`: 170 ms (14474/14474) — indexing all SSA functions and constructing one CHA call graph
- `candidate_index`: 259 ms (14474/14474) — indexing call targets and bounded wrapper candidates
- `cobra_inventory`: 23 ms (37/37) — inventorying build-selected typed Cobra descriptors and direct relationships
- `architecture_anchors`: 122 ms (49/49) — projecting existing exact architecture anchors
- `entrypoint_walk`: 4 ms (3/3) — walking build-selected executable entrypoints
- `detached_walk`: 330 ms (1500/1500) — recovering import-reachable registrations with unresolved entry dispatch
- `catalog_finalize`: 4 ms (103/103) — deduplicating surfaces and deriving presentation semantics
- `grounding_finalize`: 0 ms (28/28) — finalizing existing architecture grounding

## github.com/restic/restic/internal/dump.DumpTree$1

- ID: `trigger-04327ff25507f76aa3c181b9`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/dump.DumpTree$1`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/dump/common.go:38` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/internal/dump.(*Dumper).DumpTree`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/backend/azure.ParseConfig

- ID: `trigger-0f7058a9be77e54c3b8c7d36`
- Status: `confirmed_typed_registration`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `trace_ready`
- Trace readiness reason: exact route identity, registration, handler, and bounded static reachability can seed a request trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/backend/location.NoPassword`
- Dispatcher: `typed registration receiver`
- Registration: `internal/backend/azure/azure.go:50` via `typed_registration_detector`
- Wrapper chain: `github.com/restic/restic/internal/backend/all.Backends` → `github.com/restic/restic/internal/backend/azure.NewFactory`

## main

- ID: `trigger-127573abd48f6a546a515f1f`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a partial trace; downstream runtime handoff remains unresolved
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.main`
- Dispatcher: `process entry`
- Registration: `cmd/restic/main.go:161` via `gofacts-go-main`

## ls

- ID: `trigger-18ebda47643fb0c709d8f074`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_ls.go:65:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## index

- ID: `trigger-19ef1de291050feae49d133a`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_repair_index.go:34:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRepairCommand`
- Registration: `cmd/restic/cmd_repair.go:20` via `cobra-command-binding`
- Frontiers: cobra_constructor_instance_correlation_ambiguous: the same command descriptor is instantiated at multiple constructor callsites; relations remain local facts and are not composed across instances; inventory_command_path_unresolved: descriptor has multiple constructor invocation sites; a specific runtime instance cannot be selected; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## github.com/restic/restic/internal/repository.saveBlobAsync$1

- ID: `trigger-1a5ed78f063b5c57534e00f8`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/repository.saveBlobAsync$1`
- Dispatcher: `parameter r.Repository.mainWg`
- Registration: `internal/repository/repository.go:1049` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/internal/repository.(*Repository).saveBlobAsync`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/dump.writeNode$2

- ID: `trigger-1b4f546491c6631fa0c92a92`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/dump.writeNode$2`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/dump/common.go:143` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/internal/dump.(*Dumper).WriteNode` → `github.com/restic/restic/internal/dump.(*Dumper).writeNode`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## path.Join

- ID: `trigger-1d8c47f89e13b6669011c2cc`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `internal/backend/b2/b2.go:144` via `typed_registration_detector`
- Frontiers: dynamic_handler_identity: unknown handler; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## tag

- ID: `trigger-210dede18f854b0e321a7d30`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_tag.go:44:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## github.com/restic/restic/internal/repository.createIndexFromPacks$1

- ID: `trigger-22acba15194cc01496e1ab51`
- Status: `confirmed_worker_registration`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/repository.createIndexFromPacks$1`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/repository/repository.go:776` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/internal/repository.(*Repository).createIndexFromPacks`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/restic.E

- ID: `trigger-2ab40d45ab2511b2f7f57198`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `cmd/restic/cmd_backup.go:395` via `typed_registration_detector`
- Wrapper chain: `github.com/restic/restic/cmd/restic.runBackup` → `github.com/restic/restic/cmd/restic.collectRejectFuncs`
- Frontiers: dynamic_handler_identity: unknown handler; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/helpers/build-release-binaries.buildTargets$1

- ID: `trigger-2b521e671724261d43ea4d46`
- Status: `confirmed_worker_registration`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `helpers/build-release-binaries`; role `tooling`; availability `available`
- Handler: `github.com/restic/restic/helpers/build-release-binaries.buildTargets$1`
- Dispatcher: `*golang.org/x/sync/errgroup.Group@helpers/build-release-binaries/main.go:218:6`
- Registration: `helpers/build-release-binaries/main.go:222` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/helpers/build-release-binaries.buildTargets`

## restore

- ID: `trigger-2f886c732a06060c9ac37703`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_restore.go:53:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## restic

- ID: `trigger-338f66bf689e7492fd341138`
- Status: `partial_cobra_activation`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command activation can seed a partial path; child dispatch and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `Run/RunE descriptor initializer unresolved`
- Dispatcher: `no exact shallow registration or activation`
- Registration: unresolved via `cobra-command-activation`
- Frontiers: cobra_constructor_instance_correlation_ambiguous: the same command descriptor is instantiated at multiple constructor callsites; relations remain local facts and are not composed across instances; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## github.com/restic/restic/internal/restic.ParallelList$1

- ID: `trigger-355c31fa241dcf9de5d84e8e`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/restic.ParallelList$1`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/restic/parallel.go:22` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/internal/data.ForAllSnapshots` → `github.com/restic/restic/internal/restic.ParallelList`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## list

- ID: `trigger-3771155913ce943bdc32d54e`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_list.go:42:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: command segment is not an exact declared constant; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## copy

- ID: `trigger-3828cc2152b1c74f1f87bb9f`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_copy.go:54:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## check

- ID: `trigger-38b026eca755ee6c13a9297d`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_check.go:54:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## synthetic.ParallelRemove[github.com/restic/restic/internal/restic.FileType]$1

- ID: `trigger-3c378c71055df826b5dfc3b1`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `synthetic.ParallelRemove[github.com/restic/restic/internal/restic.FileType]$1`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/restic/parallel.go:70` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/cmd/restic.runRepairPacks` → `github.com/restic/restic/internal/repository.RepairPacks` → `github.com/restic/restic/internal/restic.ParallelRemove[github.com/restic/restic/internal/restic.FileType]`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/repository/index.Rewrite$5

- ID: `trigger-3d197038c774ca9f57ed2d6b`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/repository/index.Rewrite$5`
- Dispatcher: `*golang.org/x/sync/errgroup.Group@internal/repository/index/master_index.go:530:6`
- Registration: `internal/repository/index/master_index.go:536` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/cmd/restic.runRebuildIndex` → `github.com/restic/restic/internal/repository.RepairIndex` → `github.com/restic/restic/internal/repository.rewriteIndexFiles` → `github.com/restic/restic/internal/repository/index.(*MasterIndex).Rewrite`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## main

- ID: `trigger-3dcfbee74942ffe2586fe41c`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a partial trace; downstream runtime handoff remains unresolved
- Executable: `helpers/prepare-release`; role `tooling`; availability `available`
- Handler: `github.com/restic/restic/helpers/prepare-release.main`
- Dispatcher: `process entry`
- Registration: `helpers/prepare-release/main.go:446` via `gofacts-go-main`

## backup

- ID: `trigger-450f8d3d1e86609309f05321`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_backup.go:60:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## github.com/restic/restic/internal/backend/sftp.ParseConfig

- ID: `trigger-4a076e55e1861164b9d35f47`
- Status: `confirmed_typed_registration`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `trace_ready`
- Trace readiness reason: exact route identity, registration, handler, and bounded static reachability can seed a request trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/backend/location.NoPassword`
- Dispatcher: `typed registration receiver`
- Registration: `internal/backend/sftp/sftp.go:54` via `typed_registration_detector`
- Wrapper chain: `github.com/restic/restic/internal/backend/all.Backends` → `github.com/restic/restic/internal/backend/sftp.NewFactory`

## path.Join

- ID: `trigger-4a74d9cbe83722a8eba6b787`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `internal/backend/s3/s3.go:95` via `typed_registration_detector`
- Wrapper chain: `github.com/restic/restic/internal/backend/s3.open`
- Frontiers: dynamic_handler_identity: unknown handler; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## path.Join

- ID: `trigger-504beceb866e70d5173d8779`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `internal/backend/sftp/sftp.go:131` via `typed_registration_detector`
- Wrapper chain: `github.com/restic/restic/internal/backend/sftp.startClient`
- Frontiers: dynamic_handler_identity: unknown handler; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/cmd/restic.runBackup$3

- ID: `trigger-52b4dfa8bfadfb338598aeec`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.runBackup$3`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `cmd/restic/cmd_backup.go:652` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/cmd/restic.runBackup`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/debug.padFile

- ID: `trigger-536090364f00b45b95edf81f`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `internal/debug/debug.go:115` via `typed_registration_detector`
- Wrapper chain: `github.com/restic/restic/internal/debug.initDebugTags`
- Frontiers: dynamic_handler_identity: unknown handler; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## rebuild-index

- ID: `trigger-5410cf7a15b9a069acd5122f`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_repair_index.go:64:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## list

- ID: `trigger-56e8f31777ad33a0f7801935`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_key_list.go:37:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newKeyCommand`
- Registration: `cmd/restic/cmd_key.go:20` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## repair

- ID: `trigger-578ff7a80472bd9566d2cc35`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `Run/RunE descriptor initializer unresolved`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## github.com/restic/restic/internal/repository.startPackUploader$1

- ID: `trigger-5af48cb7d9727c8d45bc1aa1`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/repository.startPackUploader$1`
- Dispatcher: `parameter wg`
- Registration: `internal/repository/repository.go:611` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/internal/repository.(*Repository).startPackUploader`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/restorer.VerifyFiles$1

- ID: `trigger-5d00491db490ad556daefe37`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/restorer.VerifyFiles$1`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/restorer/restorer.go:641` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/cmd/restic.runRestore` → `github.com/restic/restic/internal/restorer.(*Restorer).VerifyFiles`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## snapshots

- ID: `trigger-61b04b3471432bcaa2d135f0`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_snapshots.go:45:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## result of fmt.Sprintf

- ID: `trigger-6605d40dddef71abe85bb284`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/feature.TestSetFlag$1`
- Dispatcher: `typed registration receiver`
- Registration: `internal/feature/testing.go:28` via `typed_registration_detector`
- Frontiers: dynamic_route_identity: result of fmt.Sprintf; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/repository.ReadPacks$1

- ID: `trigger-66074e322465d0ed3c1fdaac`
- Status: `confirmed_worker_registration`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/repository.ReadPacks$1`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/repository/checker.go:295` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/internal/checker.(*Checker).ReadPacks` → `github.com/restic/restic/internal/repository.(*Checker).ReadPacks`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/repository/index.Rewrite$4

- ID: `trigger-6fd5c13f982b94c3739d37e2`
- Status: `confirmed_worker_registration`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/repository/index.Rewrite$4`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/repository/index/master_index.go:468` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/cmd/restic.runRebuildIndex` → `github.com/restic/restic/internal/repository.RepairIndex` → `github.com/restic/restic/internal/repository.rewriteIndexFiles` → `github.com/restic/restic/internal/repository/index.(*MasterIndex).Rewrite`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/backend/mem.NewFactory$1

- ID: `trigger-70a0cfd3af19f651b8fe48b7`
- Status: `confirmed_typed_registration`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/backend/location.NoPassword`
- Dispatcher: `typed registration receiver`
- Registration: `internal/backend/mem/mem_backend.go:30` via `typed_registration_detector`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/repository.repack$2

- ID: `trigger-731e111e9837406b0cd30d28`
- Status: `confirmed_worker_registration`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/repository.repack$2`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/repository/repack.go:153` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/cmd/restic.copyTree` → `github.com/restic/restic/internal/repository.CopyBlobs` → `github.com/restic/restic/internal/repository.repack`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## migrate

- ID: `trigger-7391324d7fb7ca67f3329f36`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_migrate.go:38:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## diff

- ID: `trigger-75e9f2c1489d734f6d1e22a7`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_diff.go:56:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## github.com/restic/restic/helpers/build-release-binaries.buildTargets$2

- ID: `trigger-78c66bbe74dbe612d01b10d8`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `helpers/build-release-binaries`; role `tooling`; availability `available`
- Handler: `github.com/restic/restic/helpers/build-release-binaries.buildTargets$2`
- Dispatcher: `*golang.org/x/sync/errgroup.Group@helpers/build-release-binaries/main.go:218:6`
- Registration: `helpers/build-release-binaries/main.go:233` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/helpers/build-release-binaries.buildTargets`

## main

- ID: `trigger-794651e47f2b7f20b72b336b`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a partial trace; downstream runtime handoff remains unresolved
- Executable: `helpers/build-release-binaries`; role `tooling`; availability `available`
- Handler: `github.com/restic/restic/helpers/build-release-binaries.main`
- Dispatcher: `process entry`
- Registration: `helpers/build-release-binaries/main.go:316` via `gofacts-go-main`

## init

- ID: `trigger-7a77cf09245f8e2819c888b4`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_init.go:37:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## path.Join

- ID: `trigger-7d12755b8314b2762e1323da`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `internal/backend/gs/gs.go:110` via `typed_registration_detector`
- Wrapper chain: `github.com/restic/restic/internal/backend/gs.open`
- Frontiers: dynamic_handler_identity: unknown handler; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/filter.readPatternsFromFiles$1

- ID: `trigger-7ef867fb4b09dea6d03250ab`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `internal/filter/exclude.go:88` via `typed_registration_detector`
- Wrapper chain: `github.com/restic/restic/internal/filter.(ExcludePatternOptions).CollectPatterns` → `github.com/restic/restic/internal/filter.readPatternsFromFiles` → `github.com/restic/restic/internal/filter.readPatternsFromFiles$2`
- Frontiers: dynamic_handler_identity: unknown handler; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## find

- ID: `trigger-815a5e8e4f3785e3ac35cd58`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_find.go:60:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## options

- ID: `trigger-81eb8c666b080fb8fa240ca7`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_options.go:27:8`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## recover

- ID: `trigger-81efe47089dcb34b9f5a7db0`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_recover.go:38:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## version

- ID: `trigger-853eff0db739f6ecbf9f0646`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_version.go:27:8`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## key

- ID: `trigger-855501d79b660738a3fae273`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `Run/RunE descriptor initializer unresolved`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## path.Join

- ID: `trigger-869288134dac6b365183300e`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `internal/backend/azure/azure.go:149` via `typed_registration_detector`
- Wrapper chain: `github.com/restic/restic/internal/backend/azure.open`
- Frontiers: dynamic_handler_identity: unknown handler; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## generate

- ID: `trigger-880a7136d16c743f585516d6`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_generate.go:35:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## remove

- ID: `trigger-91196a639c451124cbb4f847`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_key_remove.go:34:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newKeyCommand`
- Registration: `cmd/restic/cmd_key.go:20` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## github.com/restic/restic/internal/repository/index.SaveFallback$1

- ID: `trigger-9262bebc814dfc196343207e`
- Status: `confirmed_worker_registration`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/repository/index.SaveFallback$1`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/repository/index/master_index.go:586` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/cmd/restic.runForget` → `github.com/restic/restic/cmd/restic.runPruneWithRepo` → `github.com/restic/restic/internal/repository.(*PrunePlan).Execute` → `github.com/restic/restic/internal/repository/index.(*MasterIndex).SaveFallback`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## add

- ID: `trigger-958c7af1c411fcecb278d1c8`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_key_add.go:36:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newKeyCommand`
- Registration: `cmd/restic/cmd_key.go:20` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## path.Join

- ID: `trigger-9653c9e1c099e6c8e8b69771`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `internal/backend/swift/swift.go:75` via `typed_registration_detector`
- Frontiers: dynamic_handler_identity: unknown handler; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/restorer.VerifyFiles$2

- ID: `trigger-96f13c4ae63663941f34c0a3`
- Status: `confirmed_worker_registration`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/restorer.VerifyFiles$2`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/restorer/restorer.go:664` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/cmd/restic.runRestore` → `github.com/restic/restic/internal/restorer.(*Restorer).VerifyFiles`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/backend/swift.ParseConfig

- ID: `trigger-96f77fdf56308ec6bb739bd5`
- Status: `confirmed_typed_registration`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `trace_ready`
- Trace readiness reason: exact route identity, registration, handler, and bounded static reachability can seed a request trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/backend/location.NoPassword`
- Dispatcher: `typed registration receiver`
- Registration: `internal/backend/swift/swift.go:40` via `typed_registration_detector`
- Wrapper chain: `github.com/restic/restic/internal/backend/all.Backends` → `github.com/restic/restic/internal/backend/swift.NewFactory`

## prune

- ID: `trigger-97d1f0956a01ffa0cd8400e5`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_prune.go:44:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## github.com/restic/restic/internal/repository.createIndexFromPacks$2

- ID: `trigger-9cb92dd6ad4a772ba1b1ecd7`
- Status: `confirmed_worker_registration`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/repository.createIndexFromPacks$2`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/repository/repository.go:810` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/internal/repository.(*Repository).createIndexFromPacks`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## result of fmt.Sprintf

- ID: `trigger-a2f4fc92b254e275126772eb`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/feature.TestSetFlag$1`
- Dispatcher: `typed registration receiver`
- Registration: `internal/feature/testing.go:22` via `typed_registration_detector`
- Frontiers: dynamic_route_identity: result of fmt.Sprintf; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/repository/index.Rewrite$1

- ID: `trigger-a53650b9f5fd9f3713f94057`
- Status: `confirmed_worker_registration`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/repository/index.Rewrite$1`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/repository/index/master_index.go:413` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/cmd/restic.runRebuildIndex` → `github.com/restic/restic/internal/repository.RepairIndex` → `github.com/restic/restic/internal/repository.rewriteIndexFiles` → `github.com/restic/restic/internal/repository/index.(*MasterIndex).Rewrite`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## dump

- ID: `trigger-a6b747fc3a6ca4ffee0e7950`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_dump.go:52:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## cache

- ID: `trigger-a93b179252cfdd2b53a842c9`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_cache.go:38:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## github.com/restic/restic/internal/restic.ParallelList$2

- ID: `trigger-ab5cb8e166cf7e6cf95b27e3`
- Status: `confirmed_worker_registration`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/restic.ParallelList$2`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/restic/parallel.go:48` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/internal/data.ForAllSnapshots` → `github.com/restic/restic/internal/restic.ParallelList`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## packs

- ID: `trigger-ac357282fcd7cc4869403b16`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_repair_packs.go:36:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRepairCommand`
- Registration: `cmd/restic/cmd_repair.go:20` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## github.com/restic/restic/internal/repository.repack$1

- ID: `trigger-ac5670abc02c892d982d7322`
- Status: `confirmed_worker_registration`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/repository.repack$1`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/repository/repack.go:85` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/cmd/restic.copyTree` → `github.com/restic/restic/internal/repository.CopyBlobs` → `github.com/restic/restic/internal/repository.repack`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/repository/index.Rewrite$2

- ID: `trigger-b248d83f1aac4c26a639e32b`
- Status: `confirmed_worker_registration`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/repository/index.Rewrite$2`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/repository/index/master_index.go:457` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/cmd/restic.runRebuildIndex` → `github.com/restic/restic/internal/repository.RepairIndex` → `github.com/restic/restic/internal/repository.rewriteIndexFiles` → `github.com/restic/restic/internal/repository/index.(*MasterIndex).Rewrite`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/data.StreamTrees$1

- ID: `trigger-b4c9011d13286b378d97a593`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/data.StreamTrees$1`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/data/tree_stream.go:210` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/cmd/restic.copyTree` → `github.com/restic/restic/internal/data.StreamTrees`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/backend/local.ParseConfig

- ID: `trigger-b55a56d30602dde134098c47`
- Status: `confirmed_typed_registration`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `trace_ready`
- Trace readiness reason: exact route identity, registration, handler, and bounded static reachability can seed a request trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/backend/location.NoPassword`
- Dispatcher: `typed registration receiver`
- Registration: `internal/backend/local/local.go:37` via `typed_registration_detector`
- Wrapper chain: `github.com/restic/restic/internal/backend/all.Backends` → `github.com/restic/restic/internal/backend/local.NewFactory`

## snapshots

- ID: `trigger-b6726dd542a579085258bc56`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_repair_snapshots.go:56:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRepairCommand`
- Registration: `cmd/restic/cmd_repair.go:20` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## github.com/restic/restic/internal/dump.writeNode$1

- ID: `trigger-b717bf8985d451d35ff30aa2`
- Status: `confirmed_worker_registration`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/dump.writeNode$1`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/dump/common.go:122` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/internal/dump.(*Dumper).WriteNode` → `github.com/restic/restic/internal/dump.(*Dumper).writeNode`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/archiver.Snapshot$1$1

- ID: `trigger-b9fc24dcbf5593f7aada70cb`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/archiver.Snapshot$1$1`
- Dispatcher: `**golang.org/x/sync/errgroup.Group@internal/archiver/archiver.go:901:3`
- Registration: `internal/archiver/archiver.go:904` via `x-sync-errgroup-go`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/data.StreamTrees$2

- ID: `trigger-bb0aad021b6377651dcc5988`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/data.StreamTrees$2`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/data/tree_stream.go:217` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/cmd/restic.copyTree` → `github.com/restic/restic/internal/data.StreamTrees`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/archiver.newFileSaver$2

- ID: `trigger-bc7298dc0278b31de713404f`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/archiver.newFileSaver$2`
- Dispatcher: `**golang.org/x/sync/errgroup.Group@internal/archiver/archiver.go:901:3`
- Registration: `internal/archiver/file_saver.go:49` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/internal/archiver.(*Archiver).runWorkers` → `github.com/restic/restic/internal/archiver.newFileSaver`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## mount

- ID: `trigger-bd120a08078ced584666dd93`
- Status: `partial_cobra_descriptor`; certainty `static`; resolution `partial`
- Surface role: `descriptor`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact typed command descriptor is a useful starting point; registration and activation remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_mount.go:90:9`
- Dispatcher: `no exact shallow registration or activation`
- Registration: unresolved via `cobra-command-descriptor`
- Frontiers: cobra_binding_unresolved: typed AddCommand relation is not a direct, unconditional single-definition binding; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## github.com/restic/restic/internal/restorer.restoreFiles$3

- ID: `trigger-bfc8655d1879f6b36b070b77`
- Status: `confirmed_worker_registration`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/restorer.restoreFiles$3`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/restorer/filerestorer.go:235` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/cmd/restic.runRestore` → `github.com/restic/restic/internal/restorer.(*Restorer).RestoreTo` → `github.com/restic/restic/internal/restorer.(*fileRestorer).restoreFiles`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/dump.DumpTree$2

- ID: `trigger-c1d6eb46b26e09f51cc14c7a`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/dump.DumpTree$2`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/dump/common.go:42` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/internal/dump.(*Dumper).DumpTree`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/backend/rest.ParseConfig

- ID: `trigger-c41e0d15ebc5c2a4422dfb68`
- Status: `confirmed_typed_registration`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `trace_ready`
- Trace readiness reason: exact route identity, registration, handler, and bounded static reachability can seed a request trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/backend/rest.StripPassword`
- Dispatcher: `typed registration receiver`
- Registration: `internal/backend/rest/rest.go:48` via `typed_registration_detector`
- Wrapper chain: `github.com/restic/restic/internal/backend/all.Backends` → `github.com/restic/restic/internal/backend/rest.NewFactory`

## github.com/restic/restic/internal/repository.newPackerUploader$1

- ID: `trigger-c43e3c0787a63b174976575b`
- Status: `confirmed_worker_registration`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/repository.newPackerUploader$1`
- Dispatcher: `**golang.org/x/sync/errgroup.Group@internal/repository/repository.go:605:2`
- Registration: `internal/repository/packer_uploader.go:30` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/internal/repository.(*Repository).startPackUploader` → `github.com/restic/restic/internal/repository.newPackerUploader`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## path.Join

- ID: `trigger-c5378e7a6b36b74be04dd73c`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `internal/backend/b2/b2.go:112` via `typed_registration_detector`
- Frontiers: dynamic_handler_identity: unknown handler; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## golang.org/x/sync/errgroup.Wait

- ID: `trigger-c57d62bea819ef67f58a94bb`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `golang.org/x/sync/errgroup.Wait`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/repository/index/master_index.go:546` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/cmd/restic.runRebuildIndex` → `github.com/restic/restic/internal/repository.RepairIndex` → `github.com/restic/restic/internal/repository.rewriteIndexFiles` → `github.com/restic/restic/internal/repository/index.(*MasterIndex).Rewrite`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/repository.WithBlobUploader$1

- ID: `trigger-c826ec1595b4a77a0ab8333d`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/repository.WithBlobUploader$1`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/repository/repository.go:577` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/internal/repository.(*Repository).WithBlobUploader`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## result of os.Getenv

- ID: `trigger-cb721f07e0c59e6cef375fb0`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `dynamic_frontier`; trace readiness `unsupported`
- Trace readiness reason: route identity is unresolved and cannot select an exact request trace seed
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.main$1`
- Dispatcher: `typed registration receiver`
- Registration: `cmd/restic/main.go:168` via `typed_registration_detector`
- Frontiers: dynamic_route_identity: result of os.Getenv

## passwd

- ID: `trigger-ce319ae9c000694c0603638e`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_key_passwd.go:37:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newKeyCommand`
- Registration: `cmd/restic/cmd_key.go:20` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## github.com/restic/restic/internal/backend/rclone.ParseConfig

- ID: `trigger-ce6044e2f1d63b998fe77b18`
- Status: `confirmed_typed_registration`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `trace_ready`
- Trace readiness reason: exact route identity, registration, handler, and bounded static reachability can seed a request trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/backend/location.NoPassword`
- Dispatcher: `typed registration receiver`
- Registration: `internal/backend/rclone/backend.go:43` via `typed_registration_detector`
- Wrapper chain: `github.com/restic/restic/internal/backend/all.Backends` → `github.com/restic/restic/internal/backend/rclone.NewFactory`

## github.com/restic/restic/internal/repository/index.SaveFallback$2

- ID: `trigger-d3cdc3686b14cd93579deb5d`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/repository/index.SaveFallback$2`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/repository/index/master_index.go:624` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/cmd/restic.runForget` → `github.com/restic/restic/cmd/restic.runPruneWithRepo` → `github.com/restic/restic/internal/repository.(*PrunePlan).Execute` → `github.com/restic/restic/internal/repository/index.(*MasterIndex).SaveFallback`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## features

- ID: `trigger-da9d656d4062923553cd3d7f`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_features.go:36:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## github.com/restic/restic/internal/repository/index.Rewrite$3

- ID: `trigger-dcbbea12f05ecbb7d334bbbc`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/repository/index.Rewrite$3`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/repository/index/master_index.go:459` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/cmd/restic.runRebuildIndex` → `github.com/restic/restic/internal/repository.RepairIndex` → `github.com/restic/restic/internal/repository.rewriteIndexFiles` → `github.com/restic/restic/internal/repository/index.(*MasterIndex).Rewrite`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## unlock

- ID: `trigger-dda548140d6aea400f880f4f`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_unlock.go:33:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## github.com/restic/restic/internal/data.StreamTrees$3

- ID: `trigger-ddc819371fa50fe332b7a555`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/data.StreamTrees$3`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/data/tree_stream.go:223` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/cmd/restic.copyTree` → `github.com/restic/restic/internal/data.StreamTrees`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/backend/gs.ParseConfig

- ID: `trigger-ddde2d86f4a75a46e17f9253`
- Status: `confirmed_typed_registration`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `trace_ready`
- Trace readiness reason: exact route identity, registration, handler, and bounded static reachability can seed a request trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/backend/location.NoPassword`
- Dispatcher: `typed registration receiver`
- Registration: `internal/backend/gs/gs.go:51` via `typed_registration_detector`
- Wrapper chain: `github.com/restic/restic/internal/backend/all.Backends` → `github.com/restic/restic/internal/backend/gs.NewFactory`

## github.com/restic/restic/internal/restorer.restoreFiles$2

- ID: `trigger-e158a57d14194aad8afbdf86`
- Status: `confirmed_worker_registration`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/restorer.restoreFiles$2`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/restorer/filerestorer.go:231` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/cmd/restic.runRestore` → `github.com/restic/restic/internal/restorer.(*Restorer).RestoreTo` → `github.com/restic/restic/internal/restorer.(*fileRestorer).restoreFiles`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## forget

- ID: `trigger-e231fb113e6bdccafdd0e913`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_forget.go:54:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## github.com/restic/restic/internal/archiver.newTreeSaver$1

- ID: `trigger-e277c756f539a8e91a792f72`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/archiver.newTreeSaver$1`
- Dispatcher: `**golang.org/x/sync/errgroup.Group@internal/archiver/archiver.go:901:3`
- Registration: `internal/archiver/tree_saver.go:33` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/internal/archiver.(*Archiver).runWorkers` → `github.com/restic/restic/internal/archiver.newTreeSaver`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## synthetic.ParallelRemove[github.com/restic/restic/internal/restic.WriteableFileType]$1

- ID: `trigger-ead39f4ac784b722cd3d3e55`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `synthetic.ParallelRemove[github.com/restic/restic/internal/restic.WriteableFileType]$1`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/restic/parallel.go:70` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/cmd/restic.runForget` → `github.com/restic/restic/internal/restic.ParallelRemove[github.com/restic/restic/internal/restic.WriteableFileType]`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## github.com/restic/restic/internal/backend/b2.ParseConfig

- ID: `trigger-eb8a9c2e769ce3cbe1ac4b3c`
- Status: `confirmed_typed_registration`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `trace_ready`
- Trace readiness reason: exact route identity, registration, handler, and bounded static reachability can seed a request trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/backend/location.NoPassword`
- Dispatcher: `typed registration receiver`
- Registration: `internal/backend/b2/b2.go:43` via `typed_registration_detector`
- Wrapper chain: `github.com/restic/restic/internal/backend/all.Backends` → `github.com/restic/restic/internal/backend/b2.NewFactory`

## github.com/restic/restic/internal/debug.padFunc

- ID: `trigger-efa3e28fffcae749b1c73be4`
- Status: `dynamic_typed_registration`; certainty `static`; resolution `dynamic`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact route registration can seed only a partial trace because handler or reachability evidence is incomplete
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `unknown handler`
- Dispatcher: `typed registration receiver`
- Registration: `internal/debug/debug.go:114` via `typed_registration_detector`
- Wrapper chain: `github.com/restic/restic/internal/debug.initDebugTags`
- Frontiers: dynamic_handler_identity: unknown handler; entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## cat

- ID: `trigger-f70d60fc211e5ae8fe115c09`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_cat.go:39:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## github.com/restic/restic/internal/backend/sftp.mkdirAllDataSubdirs$1

- ID: `trigger-f76cdf4c80299c07a06ba2a3`
- Status: `confirmed_async_task_start`; certainty `static`; resolution `exact`
- Surface role: `runtime_activity`; trace readiness `unsupported`
- Trace readiness reason: runtime activity is nested asynchronous work and cannot independently establish a top-level trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/backend/sftp.mkdirAllDataSubdirs$1`
- Dispatcher: `result of golang.org/x/sync/errgroup.WithContext`
- Registration: `internal/backend/sftp/sftp.go:182` via `x-sync-errgroup-go`
- Wrapper chain: `github.com/restic/restic/internal/backend/sftp.(*SFTP).mkdirAllDataSubdirs`
- Frontiers: entrypoint_dispatch_unresolved: terminal-relevant code is import-reachable but its callback or lifecycle dispatch from the process entrypoint is unresolved

## rewrite

- ID: `trigger-fd79ded99e53a2fa7cbf31d8`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_rewrite.go:64:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## stats

- ID: `trigger-fd8ff2e3145c056618bf58b0`
- Status: `partial_cobra_registration`; certainty `static`; resolution `partial`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact direct command binding can seed a partial path; process activation and downstream effects remain unresolved
- Executable: unresolved; role `unknown`; availability `available`
- Handler: `github.com/restic/restic/cmd/restic.func_literal@cmd/restic/cmd_stats.go:66:9`
- Dispatcher: `github.com/restic/restic/cmd/restic.newRootCommand`
- Registration: `cmd/restic/main.go:76` via `cobra-command-binding`
- Frontiers: inventory_command_path_unresolved: parent descriptor has multiple constructor invocation sites; its binding and activation facts cannot be correlated; shallow_inventory_no_dispatch_proof: descriptor and direct relation facts do not prove process-to-effect dispatch; that proof is deferred to Mechanism

## github.com/restic/restic/internal/backend/s3.ParseConfig

- ID: `trigger-fe72c117c83b3160a94754dd`
- Status: `confirmed_typed_registration`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `trace_ready`
- Trace readiness reason: exact route identity, registration, handler, and bounded static reachability can seed a request trace
- Executable: `cmd/restic`; role `secondary_service`; availability `available`
- Handler: `github.com/restic/restic/internal/backend/location.NoPassword`
- Dispatcher: `typed registration receiver`
- Registration: `internal/backend/s3/s3.go:50` via `typed_registration_detector`
- Wrapper chain: `github.com/restic/restic/internal/backend/all.Backends` → `github.com/restic/restic/internal/backend/s3.NewFactory`

## Loop signals

- `channel_receive_loop` in `github.com/restic/restic/helpers/build-release-binaries.buildTargets$1` at `helpers/build-release-binaries/main.go:223`: control-flow loop contains a channel receive; channel ownership and runtime lifetime remain unproven
- `control_flow_loop` in `github.com/restic/restic/helpers/build-release-binaries.buildTargets$2` at `helpers/build-release-binaries/main.go:233`: bounded SSA control-flow cycle
- `select_event_loop` in `github.com/restic/restic/internal/dump.writeNode$1` at `internal/dump/common.go:123`: control-flow loop contains a select; cancellation and runtime branch choice remain unproven
- `select_event_loop` in `github.com/restic/restic/internal/repository.ReadPacks$1` at `internal/repository/checker.go:303`: control-flow loop contains a select; cancellation and runtime branch choice remain unproven
- `select_event_loop` in `github.com/restic/restic/internal/repository.createIndexFromPacks$1` at `internal/repository/repository.go:776`: control-flow loop contains a select; cancellation and runtime branch choice remain unproven
- `channel_receive_loop` in `github.com/restic/restic/internal/repository.createIndexFromPacks$2` at `internal/repository/repository.go:790`: control-flow loop contains a channel receive; channel ownership and runtime lifetime remain unproven
- `select_event_loop` in `github.com/restic/restic/internal/repository.newPackerUploader$1` at `internal/repository/packer_uploader.go:33`: control-flow loop contains a select; cancellation and runtime branch choice remain unproven
- `select_event_loop` in `github.com/restic/restic/internal/repository.repack$1` at `internal/repository/repack.go:87`: control-flow loop contains a select; cancellation and runtime branch choice remain unproven
- `control_flow_loop` in `github.com/restic/restic/internal/repository.repack$1` at `internal/repository/repack.go:88`: bounded SSA control-flow cycle
- `channel_receive_loop` in `github.com/restic/restic/internal/repository.repack$2` at `internal/repository/repack.go:109`: control-flow loop contains a channel receive; channel ownership and runtime lifetime remain unproven
- `select_event_loop` in `github.com/restic/restic/internal/repository/index.Rewrite$1` at `internal/repository/index/master_index.go:413`: control-flow loop contains a select; cancellation and runtime branch choice remain unproven
- `select_event_loop` in `github.com/restic/restic/internal/repository/index.Rewrite$2` at `internal/repository/index/master_index.go:432`: control-flow loop contains a select; cancellation and runtime branch choice remain unproven
- `channel_receive_loop` in `github.com/restic/restic/internal/repository/index.Rewrite$4` at `internal/repository/index/master_index.go:475`: control-flow loop contains a channel receive; channel ownership and runtime lifetime remain unproven
- `select_event_loop` in `github.com/restic/restic/internal/repository/index.Rewrite$4` at `internal/repository/index/master_index.go:475`: control-flow loop contains a select; cancellation and runtime branch choice remain unproven
- `channel_receive_loop` in `github.com/restic/restic/internal/repository/index.Rewrite$4` at `internal/repository/index/master_index.go:481`: control-flow loop contains a channel receive; channel ownership and runtime lifetime remain unproven
- `channel_receive_loop` in `github.com/restic/restic/internal/repository/index.SaveFallback$1` at `internal/repository/index/master_index.go:588`: control-flow loop contains a channel receive; channel ownership and runtime lifetime remain unproven
- `select_event_loop` in `github.com/restic/restic/internal/repository/index.SaveFallback$1` at `internal/repository/index/master_index.go:588`: control-flow loop contains a select; cancellation and runtime branch choice remain unproven
- `channel_receive_loop` in `github.com/restic/restic/internal/restic.ParallelList$2` at `internal/restic/parallel.go:36`: control-flow loop contains a channel receive; channel ownership and runtime lifetime remain unproven
- `channel_receive_loop` in `github.com/restic/restic/internal/restorer.VerifyFiles$2` at `internal/restorer/restorer.go:664`: control-flow loop contains a channel receive; channel ownership and runtime lifetime remain unproven
- `channel_receive_loop` in `github.com/restic/restic/internal/restorer.restoreFiles$2` at `internal/restorer/filerestorer.go:223`: control-flow loop contains a channel receive; channel ownership and runtime lifetime remain unproven
- `select_event_loop` in `github.com/restic/restic/internal/restorer.restoreFiles$3` at `internal/restorer/filerestorer.go:235`: control-flow loop contains a select; cancellation and runtime branch choice remain unproven

Budgets reached: `architecture_anchors`, `tasks`, `value_depth`, `value_description`, `value_evaluation_cycle`.
