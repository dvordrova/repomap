# repomap onboarding feedback

Repository: github.com/restic/restic
Direction followed:
First useful file:
Time to useful orientation:

## Correct

-

## Missing

-

## Misleading

-
