# repomap onboarding feedback

Repository: github.com/chattocorp/chatto
Direction followed:
First useful file:
Time to useful orientation:

## Correct

-

## Missing

-

## Misleading

-
