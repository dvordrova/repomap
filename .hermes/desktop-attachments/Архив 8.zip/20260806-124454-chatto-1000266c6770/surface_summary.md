# Runtime surfaces

Repository: `/Users/dvordrova/git/chatto`

Scenario: `go:darwin/amd64:tags=`

Discovered 1 static surface record(s): 1 direct, 0 wrapper-derived.

This is not a runtime trace. exact build-selected process entries, typed Cobra commands, runtime registrations and starts found through safe typed package closures, bounded wrapper propagation, and the generic typed registration detector (path string + handler) under the recorded build scenario, subject to listed diagnostics and frontiers.

## Discovery phases

- `package_load`: 5728 ms (47/47) — loading build-selected packages and dependency type information
- `ssa_build`: 2195 ms (45/45) — building SSA for repository packages with dependency type information
- `call_graph`: 1585 ms (38271/38271) — indexing all SSA functions and constructing one CHA call graph
- `candidate_index`: 1889 ms (38271/38271) — indexing call targets and bounded wrapper candidates
- `cobra_inventory`: 417 ms — inventorying build-selected typed Cobra descriptors and direct relationships
- `architecture_anchors`: 1291 ms (55/55) — projecting existing exact architecture anchors
- `entrypoint_walk`: 0 ms — walking build-selected executable entrypoints
- `detached_walk`: 37 ms (0/1500) — recovering import-reachable registrations with unresolved entry dispatch
- `catalog_finalize`: 0 ms (1/1) — deduplicating surfaces and deriving presentation semantics
- `grounding_finalize`: 0 ms (31/31) — finalizing existing architecture grounding

## main

- ID: `trigger-25dd7e03f248177662ae952e`
- Status: `confirmed_process_entry`; certainty `static`; resolution `exact`
- Surface role: `entry_surface`; trace readiness `partial_trace_ready`
- Trace readiness reason: exact process entry can seed a one-anchor partial trace; typed downstream closure is unavailable
- Executable: `cli`; role `secondary_service`; availability `unavailable`
- Unavailable reason: package or dependency closure is ill-typed under the recorded build scenario
- Handler: `hmans.de/chatto.main`
- Dispatcher: `process entry`
- Registration: `cli/main.go:5` via `gofacts-go-main`

## Unavailable packages

- `hmans.de/chatto` (`cli`): unsafe_dependency_closure
- `hmans.de/chatto/cmd` (`cli`): package_errors

## Package diagnostics

- `hmans.de/chatto/cmd`: pattern embedded/LICENSE: no matching files found (`cli/cmd/license.go:12`)

Budgets reached: `architecture_anchors`.
