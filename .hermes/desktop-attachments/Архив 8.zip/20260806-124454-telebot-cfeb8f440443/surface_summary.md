# Runtime surfaces

Repository: `/Users/dvordrova/git/telebot`

Scenario: `go:darwin/amd64:tags=`

Discovered 0 static surface record(s): 0 direct, 0 wrapper-derived.

This is not a runtime trace. exact build-selected process entries, typed Cobra commands, runtime registrations and starts found through safe typed package closures, bounded wrapper propagation, and the generic typed registration detector (path string + handler) under the recorded build scenario, subject to listed diagnostics and frontiers.

## Discovery phases

- `package_load`: 880 ms (4/4) — loading build-selected packages and dependency type information
- `ssa_build`: 53 ms (4/4) — building SSA for repository packages with dependency type information
- `call_graph`: 74 ms (3738/3738) — indexing all SSA functions and constructing one CHA call graph
- `candidate_index`: 66 ms (3738/3738) — indexing call targets and bounded wrapper candidates
- `cobra_inventory`: 13 ms — inventorying build-selected typed Cobra descriptors and direct relationships
- `architecture_anchors`: 95 ms (2/2) — projecting existing exact architecture anchors
- `entrypoint_walk`: 0 ms — walking build-selected executable entrypoints
- `detached_walk`: 2 ms (0/1500) — recovering import-reachable registrations with unresolved entry dispatch
- `catalog_finalize`: 0 ms — deduplicating surfaces and deriving presentation semantics
- `grounding_finalize`: 0 ms (2/2) — finalizing existing architecture grounding

